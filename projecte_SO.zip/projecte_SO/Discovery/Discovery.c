#define _GNU_SOURCE

#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <stdlib.h>
#include <signal.h>
#include <errno.h>
#include <sys/wait.h>
#include <time.h>
#include <math.h>
#include <sys/types.h>


#include <strings.h>
#include <pthread.h>

#include "../Libraries/Files/files.h"
#include "../Libraries/Strings/strings.h"
#include "../Libraries/Trames/Trames.h"
#include "../Libraries/Sockets/Sockets.h"
#include "../Libraries/Llistes/linkedlist.h"

#define TYPE_0x01 0x01
#define TYPE_0x06 0x06
#define TYPE_0x07 0x07

#define HEADER_NEW_BOWMAN "NEW_BOWMAN"
#define HEADER_DELETE_BOWMAN "DELETE_BOWMAN"
#define HEADER_NEW_POOLE "NEW_POOLE"
#define HEADER_DELETE_POOLE "DELETE_POOLE"

#define HEADER_CON_KO "CON_KO"
#define HEADER_CON_OK "CON_OK"

#define HEADER_UNKNOWN "UNKNOWN"


typedef struct 
{
    char *PooleIP;
    int PoolePort;
    char *BowmanIP;
    int BowmanPort;

}Discovery;





Discovery discovery;



void readConfig(int fd)
{
    discovery.PooleIP = read_until(fd, '\n');
    discovery.PoolePort = atoi(read_until(fd, '\n'));
    discovery.BowmanIP = read_until(fd, '\n');
    discovery.BowmanPort = atoi(read_until(fd, '\0'));
}

PooleData* pooleAvailable(LinkedList *pooleList) {
    if (LINKEDLIST_isEmpty(*pooleList)) {
        
        while(LINKEDLIST_isEmpty(*pooleList) == 1){

        }
    }

    int minConn = 100;
    PooleData *thisPoole;
    PooleData *bestPoole = NULL;

    LINKEDLIST_goToHead(pooleList);

    while (!LINKEDLIST_isAtEnd(*pooleList)) {
        thisPoole = LINKEDLIST_get(pooleList);

        if (thisPoole != NULL && minConn > thisPoole->NumConnections) {
            
            bestPoole = thisPoole;
            minConn = thisPoole->NumConnections;
        }
        LINKEDLIST_next(pooleList);
    }
       
    return bestPoole;
}

void newBowman(int fdBowman, LinkedList *pooleList){
    char *plotString;
    PooleData *pooleData = pooleAvailable(pooleList);

    LINKEDLIST_incrementNumConnections(pooleList,pooleData->ServerName);
    
    void **data;
    data = malloc(sizeof(void*) * 3);
    data[0] = (void*) pooleData->ServerName;
    data[1] = (void*) pooleData->serverIP;
    data[2] = (void*) integerToByte(pooleData->serverPort);

    int *dataSize;
    dataSize = malloc(sizeof(int) * 3);
    dataSize[0] = (int) strlen(pooleData->ServerName);
    dataSize[1] = (int) strlen(pooleData->serverIP);
    dataSize[2] = 4;

    plotString = plotGenerator(TYPE_0x01, HEADER_CON_OK,(void**) data,3,dataSize);

    write(fdBowman,plotString,256);

    free(dataSize);
    free(data);
    free(plotString);
}

void deleteBowman(int fdBowman, LinkedList *pooleList, Plot plot){
    char *plotString;

    LINKEDLIST_decrementNumConnections(pooleList, strtok(plot.data, "[]&"));

    plotString = plotGenerator(TYPE_0x06, HEADER_CON_OK, NULL, 0,NULL);

    write(fdBowman,plotString,256);
    free(plotString);
}

void showBowmansConnected(LinkedList *pooleList)
{
    char *buffer;
    int i = 0;
    PooleData *pooleData;
    LINKEDLIST_goToHead(pooleList);
    while(!LINKEDLIST_isAtEnd(*pooleList))
    {
        pooleData = LINKEDLIST_get(pooleList);
        asprintf(&buffer, "Num Bowmans connections in Poole %s: %d\n", pooleData->ServerName, pooleData->NumConnections);
        write(1, buffer, strlen(buffer));
        free(buffer);
        LINKEDLIST_next(pooleList);
        i++;
    }
}

void* BowmanConnection(void * thread_data)
{
    LinkedList *pooleList = (LinkedList *)thread_data;
    int sockfd = serverConnection(discovery.BowmanPort);
    
    Plot plot;
    while(1)
    {        
        int fdBowman = accept (sockfd, NULL, NULL);

        plot = plotReader(fdBowman);
        
        showBowmansConnected(pooleList);
        if((plot.type == TYPE_0x01) && (strcmp(plot.HEADER, HEADER_NEW_BOWMAN) == 0))
        {     
            newBowman(fdBowman, pooleList);
        }else if((plot.type == TYPE_0x06) && (strcmp(plot.HEADER, HEADER_DELETE_BOWMAN) == 0))
        {
            deleteBowman(fdBowman, pooleList, plot);
        }else{
            char *plotString;
            plotString = plotGenerator(TYPE_0x07, HEADER_UNKNOWN, NULL, 0, NULL);
            write(fdBowman, plotString, 256);
            free(plotString);
        }
        showBowmansConnected(pooleList);
        freePlot(plot);
        close(fdBowman);
    }
    close(sockfd);
    return NULL;
}

int userAlreadyRegistered(char *serverName, LinkedList *pooleList) {
    if (LINKEDLIST_isEmpty(*pooleList)) {
        return 0;
    }

    LINKEDLIST_goToHead(pooleList);

    while (!LINKEDLIST_isAtEnd(*pooleList)) {
        PooleData *thisPoole = LINKEDLIST_get(pooleList);
        if (strcmp(serverName, thisPoole->ServerName) == 0) {
            return 1;  
        }
        LINKEDLIST_next(pooleList);
    }

    return 0;  
}

void newPoole(int fdPoole, LinkedList *pooleList, Plot plot){
    char *plotString;
    char *userName = strtok(plot.data, "&"); 

    if(userAlreadyRegistered(userName, pooleList) == 0 ) 
    {
        PooleData *pooleData = malloc(sizeof(PooleData)); 
        char *buffer;
        write(1, "New Poole connected\n", strlen("New Poole connected\n"));

        pooleData->ServerName = strdup(userName); 
        asprintf(&buffer, "Server name: %s\n", pooleData->ServerName);
        write(1, buffer, strlen(buffer));
        free(buffer);

        pooleData->NumConnections = 0;

        pooleData->serverIP = strdup(strtok(NULL, "&"));
        asprintf(&buffer, "Server IP: %s\n", pooleData->serverIP);
        write(1, buffer, strlen(buffer));
        free(buffer); 

        pooleData->serverPort = byteToInteger(strtok(NULL, "&"));
        asprintf(&buffer, "Server port: %d\n", pooleData->serverPort);
        write(1, buffer, strlen(buffer));
        free(buffer);

        LINKEDLIST_add(pooleList,pooleData);
        
        plotString = plotGenerator(TYPE_0x01, HEADER_CON_OK, NULL,0,NULL);
    }else
    {
        plotString = plotGenerator(TYPE_0x01, HEADER_CON_KO, NULL,0,NULL);
    }

    write(fdPoole, plotString, 256);
    free(plotString);

    free(plot.data);
    free(plot.HEADER);
}

void deletePoole(int fdPoole, LinkedList *pooleList, Plot plot){

    PooleData pooleData;
    char *plotstring;
    LINKEDLIST_goToHead(pooleList);
    while(LINKEDLIST_isAtEnd(*pooleList) == 0){

        pooleData = *LINKEDLIST_get(pooleList);
        if(strcmp(plot.data, pooleData.ServerName) == 0){
            LINKEDLIST_remove(pooleList);


            plotstring = plotGenerator(TYPE_0x06, HEADER_CON_OK,NULL,0,NULL);
            write(fdPoole, plotstring, 256);
            free(plotstring);
            return;
        }
        LINKEDLIST_next(pooleList);
    }

    plotstring = plotGenerator(TYPE_0x06, HEADER_CON_KO,NULL,0,NULL);
    write(fdPoole, plotstring, 256);
    free(plotstring);
}

void* PooleConnection(void * thread_data)
{
    LinkedList *pooleList = (LinkedList *) thread_data;
    int sockfd = serverConnection(discovery.PoolePort);
    
    while(1)
    {
        int fdPoole = accept (sockfd, NULL, NULL);

        Plot plot = plotReader(fdPoole);
        
        if((plot.type == TYPE_0x01) && (strcmp(plot.HEADER, HEADER_NEW_POOLE) == 0)){

            newPoole(fdPoole, pooleList, plot);
        }else if ((plot.type == TYPE_0x06) && (strcmp(plot.HEADER, HEADER_DELETE_POOLE) == 0))
        {
            deletePoole(fdPoole, pooleList, plot);
        }else{
            write(1, "\nUnknown command received!!!\n", strlen("\nUnknown command received!!!\n"));
            char *plotString;
            plotString = plotGenerator(TYPE_0x07, HEADER_UNKNOWN, NULL, 0, NULL);
            write(fdPoole, plotString, 256);
            free(plotString);
        }
        close(fdPoole);
    }
    close(sockfd);
}

int main(int argc, char *argv[])
{
    int fdConfig;

    if(argc != 2)
    {
        write(1, "ERROR: you need 2 arguments!", strlen("ERROR: you need 2 arguments!"));
    }
    openFile(&fdConfig, argv[1]);
    
    readConfig(fdConfig);

    pthread_t thread_id_1;
    pthread_t thread_id_2;
    
    LinkedList pooleList = LINKEDLIST_create();
    
    
    pthread_create( &thread_id_1, NULL, BowmanConnection, (void*)&pooleList);  //connexió bowman

    pthread_create( &thread_id_2, NULL, PooleConnection, (void*)&pooleList);  //connexió bowman

    
    pthread_join(thread_id_1, NULL);


    pthread_join(thread_id_2, NULL);
  

    



    return 0;
}