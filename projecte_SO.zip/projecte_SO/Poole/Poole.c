#define _GNU_SOURCE
#include "../Libraries/Semaphore/semaphore_v2.h"
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <stdlib.h>
#include <signal.h>
#include <errno.h>
#include <sys/wait.h>
#include <time.h>
#include <math.h>
#include <sys/shm.h>

#include <sys/types.h>
#include <sys/wait.h>
#include <string.h>
#include <signal.h>
#include <pthread.h>

#include "../Libraries/Files/files.h"
#include "../Libraries/Strings/strings.h"
#include "../Libraries/Trames/Trames.h"
#include "../Libraries/Sockets/Sockets.h"
#include "../Libraries/Library/Library.h"
#include "../Libraries/Cues/Cues.h"


#define SONGS_FILE_PATH "songs.txt"
#define STATS_FILE_PATH "stats.txt"

#define TYPE_0x01 0x01
#define TYPE_0x02 0x02
#define TYPE_0x03 0x03
#define TYPE_0x06 0x06
#define TYPE_0x07 0x07



#define HEADER_NEW_POOLE "NEW_POOLE"
#define HEADER_DELETE_POOLE "DELETE_POOLE"

#define HEADER_LIST_SONGS "LIST_SONGS"
#define HEADER_LIST_PLAYLISTS "LIST_PLAYLISTS"
#define HEADER_DOWNLOAD_SONG "DOWNLOAD_SONG"
#define HEADER_DOWNLOAD_PLAYLIST "DOWNLOAD_LIST"
#define HEADER_DOWNLOAD_LIST "DOWNLOAD_LIST"
#define HEADER_EXIT "EXIT"

#define HEADER_CON_OK "CON_OK"
#define HEADER_CON_KO "CON_KO"

#define HEADER_UNKNOWN "UNKNOWN"


typedef struct _poole{
    char *server_name;
    char *server_path;
    char *discovery_ip;
    int discovery_port;
    char *poole_ip;
    int poole_port;
    int fdPooleServer;
    char **usersNames;
    int *fdBowman;  
    int numBowmans;
    pthread_t *threads_ids;
}Poole;

typedef struct _threadCleanUp{
    int fdBowman;
    Plot plot;
    pthread_t *threads_mp3_ids;
    int numThreadsMp3;
}ThreadCleanUp;

typedef struct _songsstats{

    char *name;
    int times;
}SongsStats;

typedef struct _argsthreadsend{
    char *songName;
    int fdBowman;
}ArgsThreadSend;

Poole poole;

Library library;

char **songsNamesMonolit;

int Check_Ampersand(char *c){
    int i=0;
    while(i<(int)strlen(c)){
        if(c[i++]=='&'){
            return 1;
        }
    }
    return 0;
}

void readConfig(int fd){
    poole.server_name = read_until(fd,'\n');
    if(Check_Ampersand(poole.server_name)){
        exit(0); //Implementar FreeTheMalloc
    }
    poole.server_path = read_until(fd,'\n');
    poole.discovery_ip = read_until(fd,'\n');
    char *port = read_until(fd,'\n');
    poole.discovery_port = atoi(port);
    free(port);
    poole.poole_ip = read_until(fd,'\n');
    port = read_until(fd,'\n');
    poole.poole_port = atoi(port);
    songsNamesMonolit = malloc(sizeof(char*) * 10); //creem un buffer de 10 cançons pels stats

    poole.fdBowman = malloc(sizeof(int));
    poole.threads_ids = malloc(sizeof(pthread_t));
    poole.usersNames = malloc(sizeof(char*));
    poole.numBowmans = 0;
    free(port);
}

void printPoole(){

    char *c;

    asprintf(&c,"Server Name - %s \nServer Directory - %s\nDiscovery IP - %s\nDiscovery Port - %d\nServer IP - %s\nServer Port - %d\n",poole.server_name,poole.server_path,poole.discovery_ip,poole.discovery_port,poole.poole_ip,poole.poole_port);
    write(1,c,strlen(c));
    free(c);
    
}

void freeLibrary(){

    int i = 0;
    int n;
    while(library.numSongs > i){  //esborrem les Song

        n = 0;
        while(library.songs[i].numPlaylists > n){
            free(library.songs[i].playlists[n]);
            n++;
        }
        free(library.songs[i].playlists);
        free(library.songs[i].songName);
        i++;
    }
    free(library.songs);

    i = 0;
    //int m;
    while(library.numPlaylists > i){  //esborrem les Playlist

        n = 0;
        while(library.playlists[i].numSongs > n){   //esborrem les Song de les Playlist
            /*
            m = 0;
            while(library.playlists[i].songs[n].numPlaylists > m){
                free(library.playlists[i].songs[n].playlists[m]);
                m++;
            }*/
            
            free(library.playlists[i].songs[n].songName);
            n++;
        }
        free(library.playlists[i].playlistName);
        free(library.playlists[i].songs);
        i++;
    }
    free(library.playlists);
}

void FreeTheMalloc(){

    while(poole.numBowmans > 0){
        free(poole.usersNames[poole.numBowmans - 1]);
        pthread_cancel(poole.threads_ids[poole.numBowmans - 1]);
        pthread_join(poole.threads_ids[poole.numBowmans - 1], NULL);
        close(poole.fdBowman[poole.numBowmans - 1]);
        poole.numBowmans--;
    }
    free(poole.server_path);
    free(poole.poole_ip);
    poole.poole_ip = NULL;
    free(poole.threads_ids);
    close(poole.fdPooleServer);
    free(poole.fdBowman);
    free(poole.server_name);
    free(poole.discovery_ip);
    free(poole.usersNames);
    free(songsNamesMonolit);

    freeLibrary();
    while(poole.fdPooleServer == -1){}

    semaphore fdBowmanSemaphore;
    SEM_constructor_with_name(&fdBowmanSemaphore, ftok("Poole.c", 'A'));

    semaphore PooleControl;
    SEM_constructor_with_name(&PooleControl, ftok("Poole.c", 'B' + getpid()));

    SEM_destructor(&PooleControl);
    SEM_destructor(&fdBowmanSemaphore);
}

void warnDiscoveryAboutDisconnection(){
    int fdDsicovery = clientConnection(poole.discovery_port, poole.discovery_ip, "DISCOVERY");

    if(fdDsicovery<0){
        FreeTheMalloc();
        exit(-1);
    }

    void **data;                       //[PooleName]
    data = malloc(sizeof(void*) * 1);
    data[0] = (void*) poole.server_name;

    int *dataSize;
    dataSize = malloc(sizeof(int) * 1);
    dataSize[0] = (int) strlen(poole.server_name);

    void *plot = plotGenerator(TYPE_0x06, HEADER_DELETE_POOLE, data, 1, dataSize);

    write(fdDsicovery,plot,256);

    free(plot);
    free(dataSize);
    free(data);
    close(fdDsicovery);
}

void SigintHandler(){

    warnDiscoveryAboutDisconnection();
    write(1, "\n\nCTRL+C call...\n\n", strlen("\n\nCTRL+C call...\n\n"));
    FreeTheMalloc();
    exit(0);

}

void SignalConfig(){
    signal(SIGINT,SigintHandler);
}

int Handle_Discovery_Poole(int fdDiscoverySocket){

    Plot plot = plotReader(fdDiscoverySocket);
    int i;
    if(plot.type == TYPE_0x01 && strcmp(HEADER_CON_OK,plot.HEADER) == 0){//Conexio correcte
        write(1, "\nConnecting to Discovery...\n", strlen("\nConnecting to Discovery...\n"));
        i = 1;
    }else if(plot.type == TYPE_0x01 && strcmp(HEADER_CON_KO,plot.HEADER) == 0){
        write(1, "\nUnable to connect to Discovery...\n", strlen("\nUnable to connect to Discovery...\n"));
        i = -1;
    }else{
        write(1, "\nUnknown command received!!!\n", strlen("\nUnknown command received!!!\n"));
        char *plotString;
        plotString = plotGenerator(TYPE_0x07, HEADER_UNKNOWN, NULL, 0, NULL);
        write(fdDiscoverySocket, plotString, 256);
        free(plotString);

        i = -1;
    }
    free(plot.data);
    free(plot.HEADER);
    close(fdDiscoverySocket);

    return i;
}

char *getFullHeader(char *header, int numBytes){ 
    char *fullHeader;
    char *numBytesString;
    asprintf(&numBytesString, "%d", numBytes);

    fullHeader = malloc((int)strlen(header) + (int)strlen(numBytesString) + 1);
    fullHeader[0] = '\0';

    strcat(fullHeader, header);
    strcat(fullHeader, numBytesString);

    free(numBytesString);
    
    return fullHeader;    
}

void sendListSongs(int fdBowman){

    char *plotString;
    char **dataStrings;

    int i = 0;
    int numTotalBytes;
    dataStrings = (char **) SongDataGenerator(library, &numTotalBytes);
    char *header;
    header = getFullHeader("SONGS_RESPONSE", numTotalBytes);
    int dataStringLength;
    
    while(dataStrings[i] != NULL){  
        dataStringLength = strlen(dataStrings[i]);
        plotString = plotGenerator(TYPE_0x02, header, (void **)&(dataStrings[i]), 1, &dataStringLength);
        write(fdBowman, plotString, 256);
        free(plotString);
        i++;
    }
    


    freeTheData((void**) dataStrings);

    free(header);
}

void sendListPlaylists(int fdBowman){

    char *plotString;
    char **dataStrings;

    int i = 0;
    int numTotalBytes;
    dataStrings = (char **) PlaylistDataGenerator(library, &numTotalBytes);   //numTotalbyte, cambiar?????
    char *header;
    header = getFullHeader("PLAYLISTS_RESPONSE", numTotalBytes);
    int dataStringLength;
    
    while(dataStrings[i] != NULL){  
        dataStringLength = strlen(dataStrings[i]);

        plotString = plotGenerator(TYPE_0x02, header, (void **)&(dataStrings[i]), 1, &dataStringLength);
        write(fdBowman, plotString, 256);
        free(plotString);
        i++;
    }

    freeTheData((void**) dataStrings);

    free(header);
}

void *sendMP3data(void *argv){

    ArgsThreadSend *argsThreadSend = (ArgsThreadSend*) argv;

    

    char *plotString;
    char **dataStrings;

    int i = 0;

    
    while(i<library.numSongs){
        if(strcmp(library.songs[i].songName,argsThreadSend->songName)==0) break;
        i++;
    }

    char *fileName;
    asprintf(&fileName,"%s.mp3",argsThreadSend->songName);
    
    dataStrings = (char **) Mp3DataGenerator(fileName, library.songs[i].idFile);
    int *dataStringLength = (int*) malloc(sizeof(int));
    dataStringLength[0] = 244;
    
    i = 0;
    plotString = plotGenerator(0x04, "NEW_FILE", (void **)&(dataStrings[i]), 1, dataStringLength);
    write(argsThreadSend->fdBowman, plotString, 256);
    free(plotString);
    i++;

    
    while(dataStrings[i] != NULL){  
        plotString = plotGeneratorNewFile(0x04, "FILE_DATA", (void **)&(dataStrings[i]), 1, dataStringLength);
        write(argsThreadSend->fdBowman, plotString, 256);
        //usleep(100000); //debug
        free(plotString);
        i++;
    }
    
    free(fileName);
    free(dataStringLength);
    free(argsThreadSend->songName);
    free(argsThreadSend);
    freeTheData((void**) dataStrings);
    return NULL;
}

void uploadMonolitData(char **songsNames, int numSongs){

    semaphore PooleControl;
    SEM_constructor_with_name(&PooleControl, ftok("Poole.c", 'B' + getpid()));

    int i = 0;
    int j = 0;
    while(numSongs > j){

        songsNamesMonolit[i] = malloc(sizeof(char) * (strlen(songsNames[j]) + 1));
        strcpy(songsNamesMonolit[i], songsNames[j]);

        j++;
        i++;

        if(i == 10){
            SEM_signal(&PooleControl);
            i = 0;
            SEM_wait(&PooleControl);
        }
    }

    songsNamesMonolit[i] = NULL;

    SEM_signal(&PooleControl);
}

void sendPlaylist(ThreadCleanUp *threadCleanUp){

    char *listName = strdup(threadCleanUp->plot.data);

    int i = 0;
    while(i<library.numPlaylists){
        if(strcmp(library.playlists[i].playlistName,listName)==0) break;
        i++;
    }
    

    int m = 0;
    char **songsNames;
    songsNames = malloc(sizeof(char*) * library.playlists[i].numSongs);
    songsNames[0] = NULL;
    while(m < library.playlists[i].numSongs){

        songsNames[m] = malloc(sizeof(char) * (strlen(library.playlists[i].songs[m].songName) + 1));
        strcpy(songsNames[m], library.playlists[i].songs[m].songName);

        m++;
    }

    uploadMonolitData(songsNames, library.playlists[i].numSongs);

    int j = 0;
    while(j<library.playlists[i].numSongs){
    
        ArgsThreadSend *argsThreadSend = malloc(sizeof(ArgsThreadSend));
        argsThreadSend->songName = strdup(library.playlists[i].songs[j].songName);
        argsThreadSend->fdBowman = threadCleanUp->fdBowman;
        threadCleanUp->threads_mp3_ids = realloc(threadCleanUp->threads_mp3_ids,sizeof(pthread_t)*(threadCleanUp->numThreadsMp3+1));
            
        pthread_create( &(threadCleanUp->threads_mp3_ids[threadCleanUp->numThreadsMp3]), NULL, sendMP3data, (void*)argsThreadSend);
    
        
        j++;
    } 
}

void bowmanLeaves(Plot plot, int fdBowman){
    char *plotString;
    if(plot.type == 0x06)
    {
        char *buffer;
        asprintf(&buffer, "\nUser %s leaving...\n", plot.data);
        write(1, buffer, strlen(buffer));
        free(buffer);

        plotString = plotGenerator(TYPE_0x06, HEADER_CON_OK, NULL,0,NULL);
    }else
    {
        plotString = plotGenerator(TYPE_0x06, HEADER_CON_KO, NULL, 0, NULL);
    }
    write(fdBowman, plotString, 256);
    free(plotString);
}

void threadCleaner(void *argv){
    ThreadCleanUp threadCleanUp;
    threadCleanUp = *((ThreadCleanUp*) argv);
    for(int i = 0; i < threadCleanUp.numThreadsMp3;i++){
        pthread_join(threadCleanUp.threads_mp3_ids[i],NULL);
    }
    free(threadCleanUp.threads_mp3_ids);
    close(threadCleanUp.fdBowman);
    //freePlot(threadCleanUp.plot);
}

void* bowmanConnection(void *argv)
{
    semaphore fdBowmanSemaphore;

    SEM_constructor_with_name(&fdBowmanSemaphore, ftok("Poole.c", 'A'));

    ThreadCleanUp threadCleanUp;
    threadCleanUp.fdBowman = *((int*) argv);
    threadCleanUp.threads_mp3_ids = NULL;
    threadCleanUp.threads_mp3_ids = malloc(sizeof(pthread_t));
    threadCleanUp.numThreadsMp3 = 0;
    int bowmanArrayPosition = poole.numBowmans - 1; //variable que indica la posició als arrays que contenen les seves dades 
    SEM_signal(&fdBowmanSemaphore);

    pthread_cleanup_push(threadCleaner, (void*) &threadCleanUp);
    pthread_setcanceltype(PTHREAD_CANCEL_DEFERRED, NULL);
    threadCleanUp.plot.HEADER = NULL;
    threadCleanUp.plot.data = NULL;
    do
    {
        if(threadCleanUp.plot.HEADER != NULL){
            freePlot(threadCleanUp.plot);
        }

        pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, NULL);
        threadCleanUp.plot = plotReader(threadCleanUp.fdBowman);
        pthread_setcancelstate(PTHREAD_CANCEL_DISABLE, NULL);
        
        if((strcmp(threadCleanUp.plot.HEADER, HEADER_EXIT) == 0) && threadCleanUp.plot.type == TYPE_0x06)
        {
            bowmanLeaves(threadCleanUp.plot, threadCleanUp.fdBowman);
        }else if((strcmp(threadCleanUp.plot.HEADER, HEADER_LIST_SONGS) == 0) && threadCleanUp.plot.type == TYPE_0x02)
        {
            if(threadCleanUp.plot.type == TYPE_0x02){
                char *buffer;
                asprintf(&buffer, "\nNew request - %s requires the list of songs.\n", poole.usersNames[bowmanArrayPosition]);
                write(1, buffer, strlen(buffer));
                free(buffer);

                sendListSongs(threadCleanUp.fdBowman);
            }else{
                write(1, "ERROR: WRONG TYPE FOR HEADER -LIST_SONGS-\n", strlen("ERROR: WRONG TYPE FOR HEADER -LIST_SONGS-\n"));
            }
        }else if((strcmp(threadCleanUp.plot.HEADER, HEADER_LIST_PLAYLISTS) == 0)  && threadCleanUp.plot.type == TYPE_0x02)
        {
            if(threadCleanUp.plot.type == TYPE_0x02){
                char *buffer;
                asprintf(&buffer, "\nNew request - %s requires the list of playlists.\n", poole.usersNames[bowmanArrayPosition]);
                write(1, buffer, strlen(buffer));
                free(buffer);

                sendListPlaylists(threadCleanUp.fdBowman);
            }else{
                write(1, "ERROR: WRONG TYPE FOR HEADER -LIST_PLAYLISTS-\n", strlen("ERROR: WRONG TYPE FOR HEADER -LIST_PLAYLISTS-\n"));
            }

        }else if(strcmp(threadCleanUp.plot.HEADER, HEADER_DOWNLOAD_SONG) == 0)
        {
            if(threadCleanUp.plot.type == TYPE_0x03){

                write(1, "\nNew request - User requires download a song\n", strlen("\nNew request - User requires download a song\n"));
                char *songName = strndup(threadCleanUp.plot.data,strlen(threadCleanUp.plot.data)+1);
                int i = 0;
                while(i<library.numSongs){
                    if(strcmp(library.songs[i].songName,songName)==0) break;
                    i++;
                }
                if(i==library.numSongs){//No existeix la song
                    void *plotString = plotGenerator(TYPE_0x07,HEADER_UNKNOWN,NULL,0,NULL);
                    write(threadCleanUp.fdBowman,plotString,256);
                }else{
                    ArgsThreadSend *argsThreadSend = malloc(sizeof(ArgsThreadSend));
                    argsThreadSend->songName = strdup(songName);
                    free(songName);
                    argsThreadSend->fdBowman = threadCleanUp.fdBowman;
                    threadCleanUp.numThreadsMp3++;
                    threadCleanUp.threads_mp3_ids = realloc(threadCleanUp.threads_mp3_ids,sizeof(pthread_t)*(threadCleanUp.numThreadsMp3));
                    
                    uploadMonolitData(&(argsThreadSend->songName), 1);
                    pthread_create( &(threadCleanUp.threads_mp3_ids[threadCleanUp.numThreadsMp3 - 1]), NULL, sendMP3data, (void*)argsThreadSend);

                }
                
            }else{
                write(1, "ERROR: WRONG TYPE FOR HEADER -LIST_PLAYLISTS-\n", strlen("ERROR: WRONG TYPE FOR HEADER -LIST_PLAYLISTS-\n"));
            }

        }else if(strcmp(threadCleanUp.plot.HEADER, HEADER_DOWNLOAD_PLAYLIST) == 0)
        {
            if(threadCleanUp.plot.type == TYPE_0x03){
                char *listName = strndup(threadCleanUp.plot.data,strlen(threadCleanUp.plot.data)+1);
                write(1, "\nNew request - User requires download a playlist\n", strlen("\nNew request - User requires download a playlist\n"));
                int i = 0;
                while(i<library.numPlaylists){
                    if(strcmp(library.playlists[i].playlistName,listName)==0) break;
                    i++;
                }
                if(i==library.numPlaylists){//No existeix la playlist
                    void *plotString = plotGenerator(TYPE_0x07,HEADER_UNKNOWN,NULL,0,NULL);
                    write(threadCleanUp.fdBowman,plotString,256);
                }else{
                    sendPlaylist(&(threadCleanUp));
                }
                free(listName);
            }else{
                write(1, "ERROR: WRONG TYPE FOR HEADER -LIST_PLAYLISTS-\n", strlen("ERROR: WRONG TYPE FOR HEADER -LIST_PLAYLISTS-\n"));
            }

        }else if((strcmp(threadCleanUp.plot.HEADER, HEADER_UNKNOWN) == 0) && threadCleanUp.plot.type == TYPE_0x07){
            write(1, "\nUnknown command received!!!\n", strlen("\nUnknown command received!!!\n"));
            
        }

    }while(((strcmp(threadCleanUp.plot.HEADER, HEADER_EXIT) != 0) && threadCleanUp.plot.type != TYPE_0x06) && ((strcmp(threadCleanUp.plot.HEADER, HEADER_UNKNOWN) != 0) && threadCleanUp.plot.type != TYPE_0x07));

    pthread_cleanup_pop(1);
    close(threadCleanUp.fdBowman);
    freePlot(threadCleanUp.plot);
    return NULL;
}

void acceptConnections()
{
    poole.fdPooleServer = serverConnection(poole.poole_port);
    if(poole.fdPooleServer < 0){
        SigintHandler();
        exit(-1);
    }
    int fdConnection = -1;

    semaphore fdBowmanSemaphore;
    SEM_constructor_with_name(&fdBowmanSemaphore, ftok("Poole.c", 'A'));
    SEM_init(&fdBowmanSemaphore, 1);
   
    while(1)
    {
        write(1, "\nWaiting for connections...\n", strlen("\nWaiting for connections...\n"));
        SEM_wait(&fdBowmanSemaphore);
        fdConnection = accept (poole.fdPooleServer, NULL, NULL);

        Plot plot = plotReader(fdConnection);
        
        char *plotString;
        if((plot.type == TYPE_0x01) && (strcmp(plot.HEADER, "NEW_BOWMAN") == 0))
        {   
            
            char *buffer;
            asprintf(&buffer, "\nNew user connected: %s.\n", plot.data);
            write(1, buffer, strlen(buffer));
            free(buffer);

            plotString = plotGenerator(TYPE_0x01, HEADER_CON_OK, NULL,0,NULL);
            write(fdConnection,plotString,256);

            poole.numBowmans++;  //marca el numero de threads que s'han llençat
            poole.fdBowman = realloc(poole.fdBowman, sizeof(int) * poole.numBowmans);
            poole.fdBowman[poole.numBowmans - 1] = fdConnection;
            poole.threads_ids = realloc(poole.threads_ids, sizeof(pthread_t) * poole.numBowmans);           //incrementem memoria al array dels identificadors dels threads
            poole.usersNames = realloc(poole.usersNames, sizeof(char*) * poole.numBowmans); //incrementem memoria al array dels noms dels usuaris
            poole.usersNames[poole.numBowmans - 1] = malloc(strlen(plot.data) + 1);
            strcpy(poole.usersNames[poole.numBowmans - 1], plot.data);

            pthread_create( &(poole.threads_ids[poole.numBowmans - 1]), NULL, bowmanConnection, (void*) &fdConnection);
        }else
        {
            plotString = plotGenerator(TYPE_0x01, "CON_KO", NULL,0,NULL);
            write(fdConnection,plotString,256);
        }
        
        freePlot(plot);
        free(plotString);
        
    }
}


//------------------------------------START OF MONOLIT-----------------------------------

int readStatsFile(SongsStats **songs){

    int fdStatsFile = open(STATS_FILE_PATH, O_RDONLY);
    if(fdStatsFile < 0){
        return 0;
    }

    int numSongs;
    numSongs = 0;
    char *numSongsString;
    numSongsString = read_until(fdStatsFile, '\n'); //numero de cançons
    numSongs = atoi(numSongsString);
    free(numSongsString);

    *songs = realloc(*songs, sizeof(SongsStats) * (numSongs + 1));  //cançons amb numero de repeticions
    int i = 0;
    char *buffer;
    while(numSongs > i){
        (*songs)[i].name = read_until(fdStatsFile, '\n');
        buffer = read_until(fdStatsFile, '\n');
        (*songs)[i].times = atoi(buffer);
        free(buffer);
        
        i++;
    }
    close(fdStatsFile);

    return numSongs;
}

void writeStatsFile(SongsStats **songs, int numSongs){

    int fdStatsFile = open(STATS_FILE_PATH, O_WRONLY | O_CREAT | O_TRUNC, 0700);

    char *buffer;
    asprintf(&buffer, "%d\n", numSongs);
    write(fdStatsFile, buffer, strlen(buffer));
    free(buffer);
    int i = 0;
    while(numSongs > i){

        asprintf(&buffer, "%s\n", (*songs)[i].name);
        write(fdStatsFile, buffer, strlen(buffer));
        free((*songs)[i].name);
        free(buffer);
        asprintf(&buffer, "%d\n", (*songs)[i].times);
        write(fdStatsFile, buffer, strlen(buffer));
        free(buffer);
        i++;
    }
    close(fdStatsFile);
}

char** updateSongsList(semaphore PooleControl){
    char** updateSongsNameList;
    updateSongsNameList = malloc(sizeof(char*));

    int i = 0;
    while(songsNamesMonolit[i] != NULL){
        
        
        updateSongsNameList = realloc(updateSongsNameList, sizeof(char*) * (i + 1));
        updateSongsNameList[i] = malloc(sizeof(char) * (strlen(songsNamesMonolit[i]) + 1));
        strcpy(updateSongsNameList[i], songsNamesMonolit[i]);
        free(songsNamesMonolit[i]);
        i++;

        if(i == 10){
            SEM_signal(&PooleControl);
            i = 0;
            SEM_wait(&PooleControl);
        }
    }

    updateSongsNameList = realloc(updateSongsNameList, sizeof(char*) * (i + 1));
    updateSongsNameList[i] = NULL;

    
    
    return updateSongsNameList;
}

void updateSongsStats(char** SongsNameList, SongsStats **songsStats, int *numSongs){

    int i = 0;
    int j;
    while(SongsNameList[i] != NULL){

        j = 0;
        while(*numSongs > j){

            if((strcmp(SongsNameList[i], (*songsStats)[j].name) == 0) && (((*songsStats)[j].name) != NULL)){
                (*songsStats)[j].times++;
                break;
            }
            j++;
        }
        if(*numSongs == j){
            (*numSongs)++;
            
            (*songsStats) = realloc((*songsStats), sizeof(SongsStats) * (*numSongs));
            (*songsStats)[*numSongs - 1].name = malloc(sizeof(char) * (strlen(SongsNameList[i]) + 1));
            strcpy((*songsStats)[*numSongs - 1].name, SongsNameList[i]);
            (*songsStats)[*numSongs - 1].times = 1;
        }

        free(SongsNameList[i]);
        i++;
    }

    free(SongsNameList);
}

void updateStatsFile(char** songsNameList){

    SongsStats *songsStats;

    songsStats = malloc(sizeof(SongsStats));

    songsStats[0].name = NULL;
    songsStats[0].times = 0;

    int numSongs = readStatsFile(&songsStats);
    updateSongsStats(songsNameList, &songsStats, &numSongs);

    writeStatsFile(&songsStats, numSongs);
    free(songsStats);
}

void* Monolit(){

    char** songsNameList;

    semaphore PooleControl;
    SEM_constructor_with_name(&PooleControl, ftok("Poole.c", 'B' + getpid()));  //semafor per controlar l'accés a memoria compartida
    SEM_init(&PooleControl, 0);

    semaphore statsFileControl;
    SEM_constructor_with_name(&statsFileControl, ftok("Poole.c", 'D'));  //semafor per controlar l'accés al fitxer stats.txt
    SEM_init(&statsFileControl, 1);

    SEM_wait(&PooleControl);
    while(poole.poole_ip != NULL){
        songsNameList = updateSongsList(PooleControl);
        SEM_wait(&statsFileControl);
        updateStatsFile(songsNameList);

        SEM_signal(&statsFileControl);
        SEM_wait(&PooleControl);
    }
    
    SEM_destructor(&PooleControl);
    poole.fdPooleServer = 0;
    return NULL;
}

//------------------------------------END OF MONOLIT------------------------------------

int main(int argc,char *argv[]){
    SignalConfig();
    int fd;
    if(argc!=2){
        write(1,"No has executat correctement el Bowman",strlen("No has executat correctement el Bowman"));
        exit(0);
    }
    
    write(1, "Reading configuration file\n", strlen("Reading configuration file\n"));
    
    
    openFile(&fd,argv[1]);
    readConfig(fd);
    printPoole();
    closeFile(fd);

    poole.fdPooleServer = serverConnection(poole.poole_port);
    if(poole.fdPooleServer < 0){
        SigintHandler();
        exit(-1);
    }
    close(poole.fdPooleServer);

    int fdDiscoverySocket;

    //Conexio discovery
    fdDiscoverySocket  = clientConnection(poole.discovery_port, poole.discovery_ip, "DISCOVERY");
    if(fdDiscoverySocket<0){
        FreeTheMalloc();
        exit(-1);
    }
    write(1, "Connected to HAL 9000 System, ready to listen to Bowmans petitions\n", strlen("Connected to HAL 9000 System, ready to listen to Bowmans petitions\n"));
    //Protocol discovery
    void **data;
    data = malloc(sizeof(void*) * 3);
    data[0] = (void*) poole.server_name;
    data[1] = (void*) poole.poole_ip;
    data[2] = (void*) integerToByte(poole.poole_port);

    int *dataSize;
    dataSize = malloc(sizeof(int) * 3);
    dataSize[0] = (int) strlen(poole.server_name);
    dataSize[1] = (int) strlen(poole.poole_ip);
    dataSize[2] = (int) sizeof(int);
    
    void *plot = plotGenerator(TYPE_0x01,HEADER_NEW_POOLE,data,3, dataSize);
    
    write(fdDiscoverySocket,plot,256);
    free(data[2]);
    free(data);
    free(dataSize);
    free(plot);

    pthread_t thread_id;
    if(Handle_Discovery_Poole(fdDiscoverySocket) == 1)
    {
        pthread_create(&thread_id, NULL, Monolit, NULL);
        pthread_detach(thread_id);
        library = LIBRARY_read_file(SONGS_FILE_PATH);
        acceptConnections();
    }

    return 0;
}