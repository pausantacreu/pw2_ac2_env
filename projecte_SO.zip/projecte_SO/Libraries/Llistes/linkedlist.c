#include "linkedlist.h"

/**************************************************************************** 
 *
 * @Objective: Creates an empty linked list.
 *             If the list fails to create the phantom node, it will set
 *             the error code to LIST_ERROR_MALLOC.
 *
 *        +---+
 *   head | o-|---------
 *        +---+         |
 *   prev | o-|---------|--
 *        +---+         | |
 *                      v v          Point of View (After the last element)
 *                    +---+----+   
 *                    |   |NULL| 
 *                    +---+----+   
 *
 * @Parameters: ---
 * @Return: An empty linked list
 *
 ****************************************************************************/
LinkedList LINKEDLIST_create() {
    LinkedList list;
    list.head = (Node*)malloc(sizeof(Node));
    if (list.head != NULL) {
        list.head->next = NULL;
        list.head->data = NULL;
        list.previous = list.head;
        list.error = LIST_NO_ERROR;
    } else {
        list.error = LIST_ERROR_MALLOC;
    }
    return list;
}

/**************************************************************************** 
 *
 * @Objective: Inserts the specified element in this list before the element
 *             who is the current point of view. Shifts the point of view
 *             element (if any) and any subsequent elements to the right.
 *             If the list fails to create the new node to store the element,
 *             it will set the error code to LIST_ERROR_MALLOC.
 *
 *        +---+
 *   head | o-|---------
 *        +---+         |
 *   prev | o-|---------|-----------  Will point to 4.
 *        +---+         |           |
 *                      v           v          Point of View
 *                    +---+---+   +---+---+     +---+---+     +---+----+ 
 *                    |   | o-|-->| 1 | o-|--X->| 2 | o-|---->| 3 |NULL| 
 *                    +---+---+   +---+---+ |   +---+---+     +---+----+
 *                                          |         ^
 *                                          |         |
 *                                          |   +---+-|-+
 *                                           -->| 4 | o | New Node
 *                                              +---+---+
 *
 * @Parameters: (in/out) list    = the linked list where to add the new element
 *              (in)     element = the element to add to the list
 * @Return: ---
 *
 ****************************************************************************/
void LINKEDLIST_add(LinkedList *list, PooleData *data) {
    Node *new_node = (Node*)malloc(sizeof(Node));
    if (new_node != NULL) {
        new_node->data = malloc(sizeof(PooleData));  
		PooleData *copiedData = malloc(sizeof(PooleData));
        copiedData->ServerName = strdup(data->ServerName); 
		copiedData->serverIP = strdup(data->serverIP); 
		copiedData->NumConnections = data->NumConnections;
		copiedData->serverPort = data->serverPort;

    	new_node->data = copiedData;
        new_node->next = list->previous->next;
        list->previous->next = new_node;

        list->previous = new_node;
        list->error = LIST_NO_ERROR;
    } else {
        list->error = LIST_ERROR_MALLOC;
    }
}


/**************************************************************************** 
 *
 * @Objective: Removes the element currently at the point of view in this 
 *             list. Shifts any subsequent elements to the left.
 *             This operation will fail if the POV is after the last valid
 *             element of the list. That will also happen for an empty list.
 *             In that situation, this operation will set the error code to
 *             LIST_ERROR_END.
 *
 *        +---+
 *   head | o-|---------                        aux (free aux!)
 *        +---+         |                        |
 *   prev | o-|---------|-----------             |
 *        +---+         |           |            |
 *                      v           v             v  POV         NEW POV
 *                    +---+---+   +---+---+     +---+---+     +---+----+ 
 *                    |   | o-|-->| 1 | o-|--X->| 2 | o-|---->| 3 |NULL| 
 *                    +---+---+   +---+---+ |   +---+---+     +---+----+
 *                                          |                   ^
 *                                          |                   |
 *                                           -------------------
 *
 * @Parameters: (in/out) list = the linked list where to remove the element
 * @Return: ---
 *
 ****************************************************************************/
void LINKEDLIST_remove(LinkedList *list) {
    if (LINKEDLIST_isAtEnd(*list)) {
        list->error = LIST_ERROR_END;
    } else {
        Node *aux = list->previous->next;
        list->previous->next = aux->next;
        free(aux->data->ServerName); 
        free(aux->data->serverIP); 
        free(aux->data); 
        free(aux);
        list->error = LIST_NO_ERROR;
    }
}

/**************************************************************************** 
 *
 * @Objective: Returns the element currently at the point of view in this list.
 *             This operation will fail if the POV is after the last valid
 *             element of the list. That will also happen for an empty list.
 *             In that situation, this operation will set the error code to
 *             LIST_ERROR_END.
 * @Parameters: (in/out) list = the linked list where to get the element
 * @Return: ---
 *
 ****************************************************************************/
PooleData* LINKEDLIST_get(LinkedList *list) {
    if (LINKEDLIST_isAtEnd(*list)) {
        list->error = LIST_ERROR_END;
        return NULL;
    } else {
        return list->previous->next->data;
    }
}

/**************************************************************************** 
 *
 * @Objective: Returns true (!0) if this list contains no elements.
 * @Parameters: (in)     list = the linked list to check
 * @Return: true (!0) if this list contains no elements, false (0) otherwise
 *
 ****************************************************************************/
int LINKEDLIST_isEmpty(LinkedList list) {
    return list.head->next == NULL;
}

/**************************************************************************** 
 *
 * @Objective: Moves the point of view to the first element in the list.
 * @Parameters: (in/out) list = the linked list to move the POV.
 * @Return: ---
 *
 ****************************************************************************/
void LINKEDLIST_goToHead(LinkedList *list) {

    list->previous = list->head;

}

/**************************************************************************** 
 *
 * @Objective: Moves the point of view to the next element in the list.
 *             If the POV is after the last element in the list (or when 
 *             the list is empty), this function will set the list's error 
 *             to LIST_ERROR_END. 
 * @Parameters: (in/out) list = the linked list to move the POV.
 * @Return: ---
 *
 ****************************************************************************/
void LINKEDLIST_next(LinkedList *list) {


    if (LINKEDLIST_isAtEnd(*list)) {
        list->error = LIST_ERROR_END;
    } else {
		
        list->previous = list->previous->next;

    }
}

/**************************************************************************** 
 *
 * @Objective: Returns true (!0) if the POV is after the last element in the
 *             list.
 * @Parameters: (in)     list = the linked to check.
 * @Return: true (!0) if the POV is after the last element in the list
 *
 ****************************************************************************/
int LINKEDLIST_isAtEnd(LinkedList list) {
    return list.previous->next == NULL;
}

/**************************************************************************** 
 *
 * @Objective: Removes all the elements from the list and frees any dynamic
 *             memory block the list was using. The list must be created
 *             again before usage.
 * @Parameters: (in/out) list = the linked list to destroy.
 * @Return: ---
 *
 ****************************************************************************/
void LINKEDLIST_destroy(LinkedList *list) {
    Node *current = list->head;
    while (current != NULL) {
        Node *next = current->next;
        free(current->data); // Liberar la memoria del dato.
        free(current);
        current = next;
    }
    list->head = NULL;
    list->previous = NULL;
}

/**************************************************************************** 
 *
 * @Objective: This function returns the error code provided by the last 
 *             operation run. The operations that update the error code are:
 *             Create, Add, Remove and Get.
 * @Parameters: (in)     list = the linked list to check.
 * @Return: an error code from the list of constants defined.
 *
 ****************************************************************************/
int LINKEDLIST_getErrorCode(LinkedList list) {
    return list.error;
}

void LINKEDLIST_incrementNumConnections(LinkedList *list, const char *serverName) {

    LINKEDLIST_goToHead(list);

    while (!LINKEDLIST_isAtEnd(*list)) {

        PooleData *currentData = LINKEDLIST_get(list);
        if (strcmp(currentData->ServerName, serverName) == 0) {
            currentData->NumConnections++;
            break;
        }

        LINKEDLIST_next(list);
    }
}


void LINKEDLIST_decrementNumConnections(LinkedList *list, const char *serverName) {

    LINKEDLIST_goToHead(list);

    while (!LINKEDLIST_isAtEnd(*list)) {

        PooleData *currentData = LINKEDLIST_get(list);
        if (strcmp(currentData->ServerName, serverName) == 0) {
            currentData->NumConnections--;
            break;
        }

        LINKEDLIST_next(list);
    }
}
