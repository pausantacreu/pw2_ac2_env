/**************************************************************************** 
 * 
 * @Objective: Linked list data structure implementation
 *             A linked list is a linear data structure, in which the 
 *             elements are not stored at contiguous memory locations.
 * @Author/s:  Eduard de Torres, David Vernet, Alberto Soto, Daniel Amo, Eduard Fernandez
 * @Creation date: 20/07/2018
 * @Last modification date: 11/04/2019
 * 
 ****************************************************************************/

#ifndef _LINKEDLIST_H_
#define _LINKEDLIST_H_

#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>  // To use dynamic memory.
#include <string.h>
#include <unistd.h>


// Constants to manage the list's error codes.
#define LIST_NO_ERROR 0
#define LIST_ERROR_FULL 1
#define LIST_ERROR_EMPTY 2
#define LIST_ERROR_MALLOC 3
#define LIST_ERROR_END 4

// Define the PooleData structure
typedef struct {
    char *ServerName;
    int serverPort;
    char *serverIP;
    int NumConnections;
} PooleData;

/*
 * Node is a recursive structure that will contain each one of the elements.
 * A node has two main fields, the data to store and a pointer to the next
 * node in the Linear Data Structure.
 */
typedef struct _Node {
    PooleData *data;  // Pointer to store data of type PooleData.
    struct _Node *next;
} Node;

// LinkedList structure definition
typedef struct {
    int error;        // Error code to keep track of failing operations;
    Node *head;       // Head/First element or Phantom node;
    Node *previous;   // Previous node before the point of view;
} LinkedList;

// Function prototypes
LinkedList LINKEDLIST_create();
void LINKEDLIST_add(LinkedList *list, PooleData *data);
void LINKEDLIST_remove(LinkedList *list);
PooleData* LINKEDLIST_get(LinkedList *list);
int LINKEDLIST_isEmpty(LinkedList list);
void LINKEDLIST_goToHead(LinkedList *list);
void LINKEDLIST_next(LinkedList *list);
int LINKEDLIST_isAtEnd(LinkedList list);
void LINKEDLIST_destroy(LinkedList *list);
int LINKEDLIST_getErrorCode(LinkedList list);
void LINKEDLIST_incrementNumConnections(LinkedList *list, const char *serverName);
void LINKEDLIST_decrementNumConnections(LinkedList *list, const char *serverName);

#endif  // _LINKEDLIST_H_
