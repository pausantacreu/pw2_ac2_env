#ifndef FILES_H
#define FILES_H

void openFile(int *fd_fitxer,char* file_name);
void closeFile(int fd_fitxer);

#endif
