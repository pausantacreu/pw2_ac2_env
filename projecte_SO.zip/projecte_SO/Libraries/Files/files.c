#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h> 



void openFile(int *fd_fitxer,char* file_name){
    *fd_fitxer=open(file_name,O_RDONLY);
    if(*fd_fitxer<0){
        write(1,"Error\n",strlen("Error\n"));
        close(*fd_fitxer);
    }
}

void closeFile(int fd_fitxer){
    if(fd_fitxer<0){
        write(1,"File not found\n",strlen("File not found\n"));
    }else{
        close(fd_fitxer);
    }
}