#ifndef SOCKETS_H
#define SOCKETS_H

#define _GNU_SOURCE
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <netinet/in.h>


int clientConnection(int port, char *ipString, char *processName);

int serverConnection(int port);



#endif