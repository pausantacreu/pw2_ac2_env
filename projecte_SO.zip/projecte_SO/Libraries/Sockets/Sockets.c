#include "Sockets.h"


int clientConnection(int port, char *ipString, char *processName)
{
    int fdsocket = socket (AF_INET, SOCK_STREAM, IPPROTO_TCP);
    char *buffer;
    if(fdsocket < 0)
    {
        asprintf(&buffer, "ERROR: not able to create %s socket!", processName);
        write(1, buffer, strlen(buffer));
        free(buffer);
        return -1;
    }

    if (port < 1 || port > 65535)
    {
        asprintf(&buffer, "ERROR: wrong %s PORT", processName);
        write(1, buffer, strlen(buffer));
        free(buffer);
        return -1;
    }

    struct in_addr ip_addr;
    if (inet_aton (ipString, &ip_addr) == 0)
    {
        asprintf(&buffer, "ERROR: wrong %s IP", processName);
        write(1, buffer, strlen(buffer));
        free(buffer);
        return -1;
    }

    struct sockaddr_in s_addr;
    bzero (&s_addr, sizeof (s_addr));
    s_addr.sin_family = AF_INET;
    s_addr.sin_port = htons (port);
    s_addr.sin_addr = ip_addr;

    if (connect (fdsocket, (void *) &s_addr, sizeof (s_addr)) < 0)
    {
        asprintf(&buffer, "Waiting to have a %s available...", processName);
        write(1, buffer, strlen(buffer));
        free(buffer);

        while(connect (fdsocket, (void *) &s_addr, sizeof (s_addr)) < 0){}
    }
    
    

    return fdsocket;
}

int serverConnection(int port)
{

    if (port < 1 || port > 65535)
    {
        write(1, "ERROR: Port out of range!", strlen("ERROR: Port out of range!"));
        exit(-1);
    }

    int sockfd = socket (AF_INET, SOCK_STREAM, IPPROTO_TCP);

    if (sockfd < 0)
    {
        write(1, "socket TCP", strlen("socket TCP"));
        exit (-1);
    }

    int bind (int sockfd, const struct sockaddr *myaddr, socklen_t addrlen);

    struct sockaddr_in s_addr;
    bzero (&s_addr, sizeof (s_addr));
    s_addr.sin_family = AF_INET;
    s_addr.sin_port = htons (port);
    s_addr.sin_addr.s_addr = INADDR_ANY;

    if (bind (sockfd, (void *) &s_addr, sizeof (s_addr)) < 0)
    {
        write(1, "Binding...", strlen("Binding..."));
        while(bind (sockfd, (void *) &s_addr, sizeof (s_addr)) < 0){}
    }

    

    listen(sockfd, 5);

    return sockfd;
}
