
#ifndef CUES_H
#define CUES_H
#define _GNU_SOURCE
#include <stdio.h>      
#include <stdlib.h>  
#include <string.h>   
#include <unistd.h>    

#include <sys/types.h> 
#include <sys/ipc.h>   
#include <sys/msg.h>  

#include <fcntl.h>     
#include <sys/socket.h>
#include <netinet/in.h> 
#include <arpa/inet.h>  

#include <errno.h>    
#include "../Trames/Trames.h"

#define MAX_CUES 50
#define MAX_CUES 50



typedef struct{
    long msgID;
    Plot plot;
}QueueMessage;
typedef struct {
    key_t keyCua;
    int idFile;
    int idCua;
}Cua;
typedef struct {
    Cua *cues;
    int numCues;
}Cues;


//extern Cues bustia; 


//extern Cues bustia; 

void cuesInit(Cues *bustia);
void cuesInit(Cues *bustia);
char *getSongNameFromPlot(Plot plot);
int getIdFromPlotNEW(Plot plot);
int getIdFromPlotDATA(Plot plot);
int cuaCreator(key_t key, int idFile,Cues *bustia);
void cuaDesctructor(int cuaID,Cues *bustia);
int getCuaFromID(int idFile ,Cues bustia);
Plot getPlotFromCua(int idCua);
char *getFileBytesFromCua(int idCua);
void createFile(int fdFile,int idCua,int totalBytes, int *percetantge);


#endif