
#include "./Cues.h"

void cuesInit(Cues *bustia){
    
    bustia->numCues = 0;
    for(int i = 0; i<MAX_CUES;i++){
        
        bustia->cues[i].keyCua = (key_t) 0;
        bustia->cues[i].idFile = -1;
        bustia->cues[i].idCua = -1;
    }

}

char *getSongNameFromPlot(Plot plot){
    
    char *token = NULL;
    char *data = strndup(plot.data,256-(plot.HEADER_LENGTH +3));
    token = strtok(data, "&");
    return token;
}
int getIdFromPlotNEW(Plot plot){
    
    char *token = NULL;
    char *data = strndup(plot.data,256-(plot.HEADER_LENGTH + 3));
    token = strtok(data, "&");
    token = strtok(NULL, "&");
    token = strtok(NULL, "&");
    token = strtok(NULL, "&");
    int idFile = atoi(token);
    free(data);
    return idFile;
}
int getIdFromPlotDATA(Plot plot){
    //char *string;
    
    char *token = NULL;
    char *data = strndup(plot.data,256-(plot.HEADER_LENGTH + 3));
    token = strtok(data, "&");
    
    int idFile = atoi(token);
    free(data);
    return idFile;
}

int cuaCreator(key_t key, int idFile,Cues *bustia) {
    int cuaID = msgget(key, 0600 | IPC_CREAT);
    if (cuaID == -1) {
        perror("Error al crear la cola de mensajes");
        //exit(EXIT_FAILURE);
    }

    bustia->numCues++;

    bustia->cues = realloc(bustia->cues, sizeof(Cua) * bustia->numCues);
    bustia->cues[bustia->numCues - 1].idCua = cuaID;
    bustia->cues[bustia->numCues - 1].keyCua = key;
    bustia->cues[bustia->numCues - 1].idFile = idFile;
    
    return cuaID;
}

// Función para eliminar una cola de mensajes
void cuaDesctructor(int cuaID,Cues *bustia) {
    if (msgctl(cuaID, IPC_RMID, NULL) == -1) {
        perror("Error al eliminar la cola de mensajes");
    }
    int i = 0;
    while(i<bustia->numCues){
        if (bustia->cues[i].idCua == cuaID){
            bustia->numCues--;
            break;
        }
        i++;
    }

    while(i<bustia->numCues){
        bustia->cues[i].idCua = bustia->cues[i + 1].idCua;
        bustia->cues[i].keyCua = bustia->cues[i + 1].keyCua;
        bustia->cues[i].idFile = bustia->cues[i + 1].idFile;
        i++;
    }

    bustia->cues = realloc(bustia->cues, sizeof(Cua) * bustia->numCues);

}

// Función para obtener el ID de cola por el identificador del flujo
int getCuaFromID(int idFile ,Cues bustia) {
    for (int i = 0; i < bustia.numCues; i++) {
        if (bustia.cues[i].idFile == idFile) { // Suponemos que el idFlujo es igual al key de la cola
            return bustia.cues[i].idCua;
        }
    }
    return -1; // Si no se encuentra una cola existente para el flujo
}

Plot getPlotFromCua(int idCua){

    
    QueueMessage msgCua;
    if(msgrcv (idCua, (void*) (&msgCua), sizeof(Plot), 1, 0)==-1) perror("MSGRCV");

    return msgCua.plot;
}


char *getFileBytesFromCua(int idCua){

    
    QueueMessage msgCua;
    if(msgrcv (idCua, (void*) (&msgCua), sizeof(Plot), 1, 0)==-1) perror("MSGRCV");
    char *idFileChar = NULL;
    char *data = strndup(msgCua.plot.data,256-(msgCua.plot.HEADER_LENGTH + 3));
    idFileChar = strtok(data, "&");
    int idFileLen = strlen(idFileChar) + 1;
    char *fileBytes = NULL;
    fileBytes = strndup(msgCua.plot.data + idFileLen,256-(msgCua.plot.HEADER_LENGTH + 3 + idFileLen));
    free(data);

    freePlot(msgCua.plot);
    return fileBytes;
}


void createFile(int fdFile, int idCua, int totalBytes, int *percetantge){
    Plot plot = getPlotFromCua(idCua);
    
    char *copy = strndup(plot.data,244);
    char *token = strtok(copy,"&");
    int idLen = strlen(token) + 1;
    float dataBytes = 244 - idLen; 
    int maxMsg = totalBytes/dataBytes;
    if (write(fdFile, plot.data + idLen, dataBytes) == -1){
        close(fdFile);
        return;
    }
    freePlot(plot);
    
    for (float i = 1; i < maxMsg ; i++) {
        Plot plot = getPlotFromCua(idCua);
        write(fdFile, plot.data + idLen, dataBytes);   
        *percetantge = ((i * dataBytes) / totalBytes) * 100;
        freePlot(plot);
    }
    
    plot = getPlotFromCua(idCua);
    int lastDataBytes = totalBytes - (maxMsg) * dataBytes;
    if (write(fdFile, plot.data + idLen, lastDataBytes) == -1){
        close(fdFile);
        return;
    }
    freePlot(plot);
    close(fdFile);
    *percetantge = 100;
    free(copy);
}