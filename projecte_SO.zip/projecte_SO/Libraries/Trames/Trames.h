#ifndef TRAMES_H
#define TRAMES_H

#define _GNU_SOURCE
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include <sys/ipc.h>

#include "../Library/Library.h"

#define PADDING_CHARACTER  "\0"

typedef struct 
{
    char type;
    int HEADER_LENGTH;
    char *HEADER;
    char *data;
}Plot;



int byteToInteger(char *bytes);

void* integerToByte(int integer);

void freeTheData(void **data);

void freePlot(Plot plot);

Plot plotReader(int fd);

void* plotGenerator(char type, char *Header, void **data, int numDades, int *dataSize);

void* plotGeneratorNewFile(char type, char *Header, void **data, int numDades, int *dataSize);

void **SongDataGenerator(Library library, int *numBytesACC);

void **PlaylistDataGenerator(Library library, int *numBytesACC);

void **Mp3DataGenerator(char *fileName, int id);

void get_MD5SUM(char *md5sum, char *path);

#endif