#include "Trames.h"
#include "../Library/Library.h"


#define songDataSize 239
#define playListDataSize 235
#define downloadDataSize 244
#define downloadNewFileSize 245


int byteToInteger(char *bytes)
{   
    
    int integer = (int) bytes[0];
    integer = integer + ((int) bytes[1]) * 256;
    integer = integer + ((int) bytes[2]) * 65536;
    integer = integer + ((int) bytes[3]) * 16777216;
    return integer;
}

void* integerToByte(int integer)
{
    int *data_integer;
    data_integer = malloc(sizeof(int) * 1);
    data_integer[0] = integer;

    void *integer_void;
    integer_void = (void *)data_integer;

    return integer_void;
}

void freeTheData(void **data)
{
    int i = 0;
    while(data[i] != NULL)
    {
        free(data[i]);
        i++;
    }
    free(data);
}

void freePlot(Plot plot){
    free(plot.HEADER);
    free(plot.data);
}

Plot plotReader(int fd)
{
    Plot plot;
    plot.type = 0;
    plot.HEADER_LENGTH = 2;
    plot.HEADER = NULL;
    plot.data = NULL;

    

    if(read(fd, &(plot.type), 1) == 0){
        return plot;
    }
    //write(1, "TRAMA LLEGIDA\n", strlen("TRAMA LLEGIDA\n")); //debug
    //printf("    Plot: %d\n", plot.type); //debug

    if(read(fd, &(plot.HEADER_LENGTH), 2) == 0){
        plot.HEADER_LENGTH = 3;
    }

    //printf("    Header length: %d\n", plot.HEADER_LENGTH); //debug
    
    plot.HEADER = malloc(plot.HEADER_LENGTH + 1);
    
    int numBytes;
    numBytes = read(fd, plot.HEADER, plot.HEADER_LENGTH);
    plot.HEADER[numBytes] = '\0';

    //printf("    Header: %s\n", plot.HEADER); //debug

    plot.data = malloc(256 - 3 - plot.HEADER_LENGTH);
    plot.data[0] = '\0';
    if(read(fd, plot.data, (256 - 3 - plot.HEADER_LENGTH)) == 0){
        plot.data[0] = '\0';
    }

    //printf("    Data: %s\n", plot.data); //debug

    return plot;
}

void* plotGenerator(char type, char *Header, void **data, int numDades, int *dataSize)
{
    char *plotString = malloc(256);
    int posPlot = 0;

    plotString[posPlot] = type;
    posPlot++;

    write(1, "TRAMA ENVIADA\n", strlen("TRAMA ENVIADA\n")); //debug
    //printf("    Type: %c\n", type); //debug

    short header_length = strlen(Header);
    //printf("    Header length: %d\n", header_length);
    
    plotString[posPlot] = (char) (header_length & 0xff);
    posPlot++;
    
    plotString[posPlot] = (char) ((header_length >> 8) & 0xff);
    posPlot++;
   
    int i = 0;
    while(header_length > i)
    {
        plotString[posPlot] = Header[i];
       
        posPlot++;
        i++;
    }
    
    //printf("    Header: %s\n", Header); //debug
    
    if(data != NULL)
    {
        char **buffer;
        buffer = (char**) data;

        i = 0;
        int n;
        while(i<numDades)
        {
            n = 0;
            while(dataSize[i] > n)
            {   
                plotString[posPlot] = buffer[i][n];
                //write(1, &buffer[i][n], 1); //debug
                posPlot++;
                n++;
            }
            
            plotString[posPlot] = '&';
            //write(1, "&", 1); //debug
            //write(1, "\n", 1); //debug
            
            posPlot++;
            i++;
        }

        plotString[posPlot - 1] = '\0'; 
    }else{
        plotString[posPlot] = '\0';
        posPlot++;
    }

    if(posPlot < 256)
    {
        i = 0;
        while(posPlot < 256)
        {
            plotString[posPlot] = '\0';
            posPlot++;
        }
    }
    return plotString;
}

void* plotGeneratorNewFile(char type, char *Header, void **data, int numDades, int *dataSize)
{
    char *plotString = malloc(256);
    int posPlot = 0;

    plotString[posPlot] = type;
    posPlot++;

    short header_length = strlen(Header);
    
    plotString[posPlot] = (char) (header_length & 0xff);
    posPlot++;
    
    plotString[posPlot] = (char) ((header_length >> 8) & 0xff);
    posPlot++;
   
    int i = 0;
    while(header_length > i)
    {
        plotString[posPlot] = Header[i];
       
        posPlot++;
        i++;
    }
    
    if(data != NULL)
    {
        char **buffer;
        buffer = (char**) data;

        i = 0;
        int n;
        while(i<numDades)
        {
            n = 0;
            while(dataSize[i] > n)
            {   
                plotString[posPlot] = buffer[i][n];
                posPlot++;
                n++;
            }
            
            posPlot++;
            i++;
        }
    }else{
        plotString[posPlot] = '\0';
        posPlot++;
    }

    return plotString;
}

void **SongDataGenerator(Library library, int *numBytesACC) {
    char **data;
    int songsLen = 0;
    int numBytesUtils = 0 ;
    
    for (int i = 0; i < library.numSongs; i++) {
        songsLen += (strlen(library.songs[i].songName) + 1); 

        
    }
    songsLen --;
    char *numBytes;
    asprintf(&numBytes,"%d",songsLen);
    int numCharBytes = strlen(numBytes);
    free(numBytes);
    
    int numDataStrings = songsLen / (songDataSize - numCharBytes ) + (songsLen % (songDataSize - numCharBytes ) != 0);


    data = malloc(sizeof(char*) * (numDataStrings + 1)); 
    for (int i = 0, songPos = 0; i < numDataStrings; i++) {
        data[i] = malloc((songDataSize - numCharBytes ));
        int stringPos = 0;

        while (songPos < library.numSongs && stringPos < ((songDataSize - numCharBytes ) - 1)) { 
            char *songName = library.songs[songPos].songName;
            int songNameLength = strlen(songName);
            
            
            if (stringPos + songNameLength < ((songDataSize - numCharBytes ) - 1)) {
                strcpy(data[i] + stringPos, songName);
                stringPos += songNameLength;
                numBytesUtils += songNameLength;

                
                if (songPos < library.numSongs - 1 && stringPos < ((songDataSize - numCharBytes ) - 1)) {
                    data[i][stringPos] = '&';
                    stringPos++;
                    numBytesUtils++;
                }
            } else {
                break; 
            }
            songPos++;
        }



        for (int j = stringPos; j < (songDataSize - numCharBytes ); j++) {
            data[i][j] = '\0';
        }
        
    }

    data[numDataStrings] = NULL; 
    *numBytesACC = numBytesUtils;
    return (void**)data;
}

void **PlaylistDataGenerator(Library library, int *numBytesACC) {
    char **data;
    int totalBytes = 0;
    *numBytesACC = 0;
    
    for (int i = 0; i < library.numPlaylists; i++) {
        totalBytes += strlen(library.playlists[i].playlistName) + 1; 
        for (int j = 0; j < library.playlists[i].numSongs; j++) { 
            totalBytes += strlen(library.playlists[i].songs[j].songName) + 1; 
        } 
    }

    totalBytes--;
    char *numBytes;
    asprintf(&numBytes,"%d",totalBytes);
    int numCharBytes = strlen(numBytes);
    free(numBytes);


    int numDataStrings = totalBytes / (playListDataSize - numCharBytes) + (totalBytes % (playListDataSize - numCharBytes) != 0);
    data = malloc(sizeof(char*) * (numDataStrings + 1));

    for (int i = 0, playlistPos = 0; i < numDataStrings; i++) {
        data[i] = malloc(235);
        int stringPos = 0;
        while (playlistPos < library.numPlaylists && stringPos < ((playListDataSize - numCharBytes) - 1)) {

            int stringAddLength = strlen(library.playlists[playlistPos].playlistName);
            
            for(int j = 0; j < library.playlists[playlistPos].numSongs;j++){
                stringAddLength += strlen(library.playlists[playlistPos].songs[j].songName);
            }
            char *playlistName = library.playlists[playlistPos].playlistName;
            int playlistLength = strlen(playlistName);
            if (stringPos + stringAddLength < ((playListDataSize - numCharBytes) - 1)) {
                strcpy(data[i] + stringPos, playlistName);
                stringPos += playlistLength;

                for (int j = 0; j < library.playlists[playlistPos].numSongs ; j++) {
                    const char *songName = library.playlists[playlistPos].songs[j].songName;
                    int songNameLength = strlen(songName);

                    data[i][stringPos++] = '&';
                    strcpy(data[i] + stringPos, songName);
                    stringPos += songNameLength;
                    
                }

                if (playlistPos < library.numPlaylists - 1 && stringPos < ((playListDataSize - numCharBytes) - 1)) {
                    data[i][stringPos++] = '#';
                }
            } else {
                break;
            }
            playlistPos++;
        }

        // Rellenar el resto con '\0'
        for (int j = stringPos; j < (playListDataSize - numCharBytes); j++) {
            data[i][j] = '\0';
        }
        
    }
    *numBytesACC = totalBytes;
    data[numDataStrings] = NULL;
    return (void**)data;
}
void get_MD5SUM(char *md5sum, char *path) {
    int fd[2];
    pipe(fd);

    pid_t pid = fork();
    if (pid == 0) {
        close(fd[0]);
        dup2(fd[1], STDOUT_FILENO);
        char *args[] = {"md5sum", path, NULL};
        execvp(args[0], args);
        raise(SIGINT);
    } else {
        close(fd[1]);
        wait(NULL);
        read(fd[0], md5sum, 32);    
        md5sum[32] = '\0';
        close(fd[0]);
    }
}

void **Mp3DataGenerator(char *fileName, int id) {
    char *string;

    char *finalFileName;
    asprintf(&finalFileName,"./SongsFiles/%s",fileName);
    int fd = open(finalFileName, O_RDONLY);
    if (fd < 0) {
        perror("Error opening file");
        return NULL;
    }


    char **data = malloc(sizeof(char*) * 2);
    int i = 1, totalBytes = 0, nByte;
    
    char *idChar;
    asprintf(&idChar,"%d&",id);
    data[i] = malloc(downloadDataSize);  
    int k;
    for(k = 0; k < (int) strlen(idChar);k++){
        data[i][k] = idChar[k];
    }
    
    int idLen = strlen(idChar);
    while (1) {
        int j = idLen;
        nByte = read(fd, (data[i] + idLen), downloadDataSize - idLen);
        totalBytes += nByte;
        
        if (nByte < (downloadDataSize - idLen)) {
            j += nByte;
            while (j < (int) (downloadDataSize)) {
                data[i][j++] = '\0';
            }

            i++;
            data = realloc(data, sizeof(char*) * (i + 1));
            data[i] = NULL;  
        
            break;
        } else {


            i++;
            data = realloc(data, sizeof(char*) * (i + 1));
            data[i] = NULL;
            data[i] = malloc((downloadDataSize));
            data[i][0] = '\0';
            int k;
            for( k = 0; k < (int) strlen(idChar);k++){
                data[i][k] = idChar[k];
            }
        }
    }
    
    
    char md5sum[32];
    get_MD5SUM(md5sum,finalFileName);
    asprintf(&string,"%s&%d&%s&%d",fileName,totalBytes,md5sum,id);
    write(1,string,strlen(string));
    int j = strlen(string);

    data[0] = strdup(string);
    data[0] = realloc(data[0],downloadNewFileSize);
    while (j < downloadNewFileSize) {
        data[0][j++]= '\0';
    }

    free(finalFileName);
    free(idChar);
    free(string);
    close(fd);
    
    return (void**) data;
}


