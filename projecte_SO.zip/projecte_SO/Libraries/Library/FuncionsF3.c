char *getSongNameFromPlot(Plot plot){
    
    char *token = NULL;
    char *data = strndup(plot.data,256-(plot.HEADER_LENGTH +3));
    token = strtok(data, "&");
    return token;
}
int getIdFromPlotNEW(Plot plot){
    
    char *token = NULL;
    char *data = strndup(plot.data,256-(plot.HEADER_LENGTH + 3));
    token = strtok(data, "&");
    token = strtok(NULL, "&");
    token = strtok(NULL, "&");
    token = strtok(NULL, "&");
    int idFile = atoi(token);
    return idFile;
}
int getIdFromPlotDATA(Plot plot){
    
    char *token = NULL;
    char *data = strndup(plot.data,256-(plot.HEADER_LENGTH + 3));
    token = strtok(data, "&");
    int idFile = atoi(token);
    char *string;
    asprintf(&string,"\ngetifFromPlotDATA() == idChar = [%s] -- idInt = [%d] \n",token,idFile);
    write(1,string,strlen(string));
    return idFile;
}
// Función para crear una cola de mensajes
int cuaCreator(key_t key, int idFile) {
    int cuaID = msgget(key, 0600 | IPC_CREAT);
    if (cuaID == -1) {
        perror("Error al crear la cola de mensajes");
        exit(EXIT_FAILURE);
    }
    bustia.cues[bustia.numCues].idCua = cuaID;
    bustia.cues[bustia.numCues].keyCua = key;
    bustia.cues[bustia.numCues++].idFile = idFile;
    return cuaID;
}

// Función para eliminar una cola de mensajes
void cuaDesctructor(int cuaID) {
    if (msgctl(cuaID, IPC_RMID, NULL) == -1) {
        perror("Error al eliminar la cola de mensajes");
    }
    int i = 0;
    while(i<bustia.numCues){
        if (bustia.cues[i].idCua == cuaID){
            bustia.cues[i].idCua = -1;
            bustia.cues[i].keyCua = (key_t) 0;
            bustia.numCues--;
            break;
        }
        i++;
    }

}

// Función para obtener el ID de cola por el identificador del flujo
int getCuaFromID(int idFile ) {
    for (int i = 0; i < bustia.numCues; i++) {
        if (bustia.cues[i].idFile == idFile) { // Suponemos que el idFlujo es igual al key de la cola
            return bustia.cues[i].idCua;
        }
    }
    return -1; // Si no se encuentra una cola existente para el flujo
}

void **Mp3DataGenerator(char *fileName,int id) {

    int fd = open(fileName, O_RDONLY);
    if (fd < 0) {
        perror("Error opening file");
        return NULL;
    }


    char **data = malloc(sizeof(char*) * 2);
    int i = 1, totalBytes = 0, nByte;
    char *idChar;
    asprintf(&idChar, "%d", id);
    data[i] = malloc(downloadDataSize - (strlen(idChar) + 1));  
    int k;
    for(k = 0; k < (int) strlen(idChar);k++){
        data[i][k] = idChar[k];
    }
    data[i][k] = '&';
    //int debug_numDataEscrita;//debug
    while (1) {
        int j = strlen(idChar) + 1 ;
        while (j < (int) (downloadDataSize - (strlen(idChar) + 1))) {
            nByte = read(fd, &data[i][j], 1);
            if (nByte <= 0) break;  
            totalBytes++;
            j++;
        }

        if (nByte <= 0) {
            while (j < (int) (downloadDataSize - (strlen(idChar) + 1))) {
                data[i][j++] = '\0';
            }

            i++;
            data = realloc(data, sizeof(char*) * (i + 1));
            data[i] = NULL;  
            
            //debug_numDataEscrita = j;
            break;
        } else {
            i++;
            data = realloc(data, sizeof(char*) * (i + 1));
            data[i] = malloc((downloadDataSize - (strlen(idChar) + 1)));
            int k;
            for( k = 0; k < (int) strlen(idChar);k++){
                data[i][k] = idChar[k];
            }
            data[i][k] = '&';
        }
    }
    char *string;
    asprintf(&string,"\n\n\n\n\n%d\n%d\n\n\n\n\n\nDATA[%d] = [%s]\n",i,totalBytes,i,data[138]);//debug
            write(1,string,strlen(string));
            free(string);
    
    for(int x = 0; x<244;x++){//debug
        if(data[138][x]=='\0'){
        
        write(1,"-",1);//debug
        }else{//debug
            char *a = (char*) malloc(sizeof(char));//debug
            *a = data[138][x];//debug
            write(1,a,1);//debug
        }
    }//debug
    char md5sum[32];
    get_MD5SUM(md5sum,fileName);
    asprintf(&string,"%s&%d&%s&%d",fileName,totalBytes,md5sum,id);
    write(1,string,strlen(string));
    sleep(2);
    int j = strlen(string);

    data[0] = strdup(string);
    data[0] = realloc(data[0],downloadDataSize + 1);
    while (j < downloadDataSize + 1) {
        data[0][j++]= '\0';
    }


    free(string);
    close(fd);
    
    /*for (int i = 0; data[i]!=NULL; i++){//debug
        //write(1,"\nData = [",strlen("\nData = ["));//debug
        asprintf(&string,"\nData[%d] = ",debug_numDataEscrita);//debug
        write(1,string,strlen(string));//debug
        free(string);//debug
        for(int x=0;x<debug_numDataEscrita;x++){
            if(data[i][x]=='\0'){//debug
            write(1,"-",1);//debug
            }else{//debug
                char *a = (char*) malloc(sizeof(char));//debug
                *a = data[i][x];//debug
                write(1,a,1);//debug
            }
        }
        write(1,"]\n",strlen("]\n"));//debug
    }*/
    
    return (void**) data;
}

void *read_function(){
    char *string;
    int port = 8295;
    char *ipString = "192.168.1.5";
    int fdsocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (fdsocket < 0) {
        fprintf(stderr, "ERROR: Socket not created: %s\n", strerror(errno));
        
    }

    struct sockaddr_in s_addr;
    bzero(&s_addr, sizeof(s_addr));
    s_addr.sin_family = AF_INET;
    s_addr.sin_port = htons(port);
    
    if (inet_aton(ipString, &s_addr.sin_addr) == 0) {
        fprintf(stderr, "ERROR: IP is not valid: %s\n", strerror(errno));
    }
    sleep(5);
    if (connect(fdsocket, (struct sockaddr *)&s_addr, sizeof(s_addr)) < 0) {
        fprintf(stderr, "ERROR: Connection error: %s\n", strerror(errno));
        close(fdsocket);
    }

    write(1,"\nR: connected\n",strlen("\nR: connected\n"));
    int i=1;
    cuaCreator(0,0);
    
    while(1){

        Plot plot = plotReader(fdsocket);
        int idCua;
        if(strcmp(plot.HEADER,"NEW_FILE")==0 ){
            write(1,"\nR: NEW_FILE\n",strlen("\nR: NEW_FILE\n"));

            char *songName = getSongNameFromPlot(plot);
            int idFile = getIdFromPlotNEW(plot);
            key_t key = ftok(songName,'A');
            idCua = cuaCreator(key,idFile);
            
        }else if (strcmp(plot.HEADER,"FILE_DATA") == 0){
            write(1,"\nR: FILE_DATA\n",strlen("\nR: FILE_DATA\n"));
            int idFile = getIdFromPlotDATA(plot);
            
            idCua = obtenerColaPorId(idFile);
            asprintf(&string,"Per idFile = %d idCua = %d \n",idFile,idCua);
            write(1,string,strlen(string));
            free(string);
            
        }else{
            write(1,"\nR: COMMAND\n",strlen("\nR: COMMAND\n"));
            idCua = 0;
        }

        MensajeCola mensaje;
        mensaje.idFlux = i;  // Usar el identificador del flujo como tipo de mensaje
        mensaje.plot = plot;
        asprintf(&string,"idCua = %d amb idFlux %ld\n",idCua,mensaje.idFlux);
        write(1,string,strlen(string));
        free(string);
        string = strdup(mensaje.plot.data,4);
        asprintf(&string,"mensaje.plot = [%s]\n",mensaje.plot.data);
        write(1,string,strlen(string));
        free(string);
        // Enviar el mensaje a la cola correspondiente
        perror("Perror abans de msgsend no fos que pasialgo altre\n");
        if (msgsnd(idCua, (void *)&mensaje, sizeof(Plot), 0) == -1) {
            perror("msgsnd falló");
            while (1)
            {     }
        }else {
            write(1,"msg enviat\n",strlen("msg enviat\n"));
        }
        
        
    }

    
    

}