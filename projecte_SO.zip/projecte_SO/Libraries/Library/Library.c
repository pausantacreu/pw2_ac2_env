#include "Library.h"

Library LIBRARY_create_library() {
    Library library;
    char *buffer;

    write(1, "Quantes cançons tens? ", strlen("Quantes cançons tens? "));
    buffer = read_until(0, '\n');
    library.numSongs = atoi(buffer);
    free(buffer);

    library.songs = malloc(sizeof(Song) * library.numSongs);

    for (int i = 0; i < library.numSongs; i++) {
        write(1, "Nom de la canço: ", strlen("Nom de la canço: "));
        buffer = read_until(0, '\n');
        library.songs[i].songName = malloc(strlen(buffer) + 1);
        strcpy(library.songs[i].songName, buffer);
        free(buffer);

        write(1, "Numero de playlist a les que pertany la canço: ", strlen("Numero de playlist a les que pertany la canço: "));
        buffer = read_until(0, '\n');
        library.songs[i].numPlaylists = atoi(buffer);
        free(buffer);

        if (library.songs[i].numPlaylists > 0) {
            library.songs[i].playlists = malloc(sizeof(char*) * library.songs[i].numPlaylists);
        } else {
            library.songs[i].playlists = NULL;
        }

        for (int j = 0; j < library.songs[i].numPlaylists; j++) {
            write(1, "Nom de la playlist: ", strlen("Nom de la playlist: "));
            buffer = read_until(0, '\n');
            library.songs[i].playlists[j] = malloc(strlen(buffer) + 1);
            strcpy(library.songs[i].playlists[j], buffer);
            free(buffer);
        }
    }

    return library;
}

void LIBRARY_save_file(int fd, Library library) {
    write(fd, &library.numSongs, sizeof(int));

    for (int i = 0; i < library.numSongs; i++) {
        int nameLen = strlen(library.songs[i].songName) + 1;
        write(fd, &nameLen, sizeof(int));
        write(fd, library.songs[i].songName, nameLen);

        write(fd, &library.songs[i].numPlaylists, sizeof(int));

        for (int j = 0; j < library.songs[i].numPlaylists; j++) {
            int playlistLen = strlen(library.songs[i].playlists[j]) + 1;
            write(fd, &playlistLen, sizeof(int));
            write(fd, library.songs[i].playlists[j], playlistLen);
        }
    }
    write(fd, &library.numPlaylists, sizeof(int));

    for (int i = 0; i < library.numPlaylists; i++) {
        int nameLen = strlen(library.playlists[i].playlistName) + 1;
        write(fd, &nameLen, sizeof(int));
        write(fd, library.playlists[i].playlistName, nameLen);

        write(fd, &library.playlists[i].numSongs, sizeof(int));

        for (int j = 0; j < library.playlists[i].numSongs; j++) {
            int playlistLen = strlen(library.playlists[i].songs[j].songName) + 1;
            write(fd, &playlistLen, sizeof(int));
            write(fd, library.playlists[i].songs[j].songName, playlistLen);
        }
    }
}

Library LIBRARY_read_file(char* fielPath) {

    int fd = open(fielPath, O_RDONLY);
    Library library;

    char *buffer;

    library.numSongs = 0;
    buffer = read_until(fd, '\n');
    library.numSongs = atoi(buffer);
    printf("Num Songs: %d\n", library.numSongs); //debug
    free(buffer);

    library.songs = malloc(sizeof(Song) * library.numSongs);
    for (int i = 0; i < library.numSongs; i++) {

        library.songs[i].songName = read_until(fd, '\n');
        printf("    Song Name: %s\n", library.songs[i].songName); //debug
        library.songs[i].idFile = 0;
        buffer = read_until(fd, '\n');
        library.songs[i].idFile = atoi(buffer);
        printf("    ID file: %d\n", library.songs[i].idFile); //debug
        free(buffer);


        library.songs[i].numPlaylists = 0;
        buffer = read_until(fd, '\n');
        library.songs[i].numPlaylists = atoi(buffer);
        printf("    Num playlists: %d\n", library.songs[i].numPlaylists);
        free(buffer);


        library.songs[i].playlists = malloc(sizeof(char*) * library.songs[i].numPlaylists);
        for (int j = 0; j < library.songs[i].numPlaylists; j++) {
            
            library.songs[i].playlists[j] = read_until(fd, '\n');
            printf("        Playlist name: %s\n", library.songs[i].playlists[j]);
        }
    }

    library.numPlaylists = 0;
    buffer = read_until(fd, '\n');
    library.numPlaylists = atoi(buffer);
    printf("Num playlists: %d\n", library.numPlaylists);
    free(buffer);

    library.playlists = malloc(sizeof(Playlist) * library.numPlaylists);
    for (int i = 0; i < library.numPlaylists; i++) {
        library.playlists[i].playlistName = read_until(fd, '\n');
        printf("    Playlist name: %s\n", library.playlists[i].playlistName);

        library.playlists[i].numSongs = 0;
        buffer = read_until(fd, '\n');
        library.playlists[i].numSongs = atoi(buffer);
        printf("    Num songs: %d\n", library.playlists[i].numSongs);
        free(buffer);

        library.playlists[i].songs = malloc(sizeof(Song) * (library.playlists[i].numSongs));
        for (int j = 0; j < library.playlists[i].numSongs; j++) {

            library.playlists[i].songs[j].songName = read_until(fd, '\n');
            printf("        Song name: %s\n", library.playlists[i].songs[j].songName);

            library.playlists[i].songs[j].idFile = 0;
            buffer = read_until(fd, '\n');
            library.playlists[i].songs[j].idFile = atoi(buffer);
            printf("        ID file: %d\n", library.playlists[i].songs[j].idFile);
            free(buffer);

        }
    }
    close(fd);
    return library;
}

void checkDirectory(char *directoryName){
    struct stat st = {0};
    if (stat(directoryName, &st) == -1) { 
        if (mkdir(directoryName, 0700) == -1) {

            exit(-1);// vigilar
        }
    }
}