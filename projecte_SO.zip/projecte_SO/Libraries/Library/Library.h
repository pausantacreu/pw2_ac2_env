#ifndef _LIBRARY_H_
#define _LIBRARY_H_

#define _GNU_SOURCE
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <errno.h>
#include "../Strings/strings.h"

typedef struct {
    char *songName;
    int idFile;
    int numPlaylists;
    char **playlists;
} Song; 

typedef struct {
    char *playlistName;
    int numSongs;
    Song *songs;
} Playlist;

typedef struct {
    int numSongs;
    Song *songs;
    int numPlaylists;
    Playlist *playlists;
} Library;


Library LIBRARY_create_library();

void LIBRARY_save_file(int fd, Library library);

Library LIBRARY_read_file(char *fielPath);
void checkDirectory(char *file);

#endif