#define _GNU_SOURCE
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <time.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <math.h>
#include <errno.h>
#include <sys/ipc.h>
#include <sys/msg.h>

#define MAX_CUES 1500
#define KEY_CUA 1234

#define songDataSize 239
#define mp3DataSize 240
#define downloadDataSize 244


typedef struct {
    char *songName;
int idFile;
    int numPlaylists; // ???
    char **playlists; // ???
} Song;

typedef struct {
    char *playlistName;
    int numSongs;
    Song *songs;
} Playlist;

typedef struct {
    int numSongs;
    Song *songs;
    int numPlaylists;
    Playlist *playlists;
} Library;
typedef struct 
{
    char type;
    int HEADER_LENGTH;
    char *HEADER;
    char *data;
}Plot;



// Definición de la estructura del mensaje para la cola de mensajes
typedef struct {
    long idFlux;  
    Plot plot; 
} MensajeCola;
typedef struct {
    key_t keyCua;
    int idFile;
    int idCua;
}Cua;
typedef struct {
    Cua cues[MAX_CUES];
    int numCues;
}Cues;
Cues bustia;
char *getSongNameFromPlotNEW(Plot plot){
    
    char *token = NULL;
    char *data = strndup(plot.data,plot.HEADER_LENGTH);
    token = strtok(data, "&");
    return token;
}
char *getSongNameFromPlot(Plot plot){
    
    char *token = NULL;
    char *data = strndup(plot.data,256-(plot.HEADER_LENGTH +3));
    token = strtok(data, "&");
    return token;
}
int getIdFromPlotNEW(Plot plot){
    
    char *token = NULL;
    char *data = strndup(plot.data,256-(plot.HEADER_LENGTH + 3));
    token = strtok(data, "&");
    token = strtok(NULL, "&");
    token = strtok(NULL, "&");
    token = strtok(NULL, "&");
    int idFile = atoi(token);
    return idFile;
}
int getIdFromPlotDATA(Plot plot){
    
    char *token = NULL;
    char *data = strndup(plot.data,256-(plot.HEADER_LENGTH + 3));
    token = strtok(data, "&");
    int idFile = atoi(token);
    char *string;
    asprintf(&string,"\ngetifFromPlotDATA() == idChar = [%s] -- idInt = [%d] \n",token,idFile);
    write(1,string,strlen(string));
    return idFile;
}
// Función para crear una cola de mensajes
int crearCola(key_t key, int idFile) {
    int cuaID = msgget(key, 0600 | IPC_CREAT);
    if (cuaID == -1) {
        perror("Error al crear la cola de mensajes");
        exit(EXIT_FAILURE);
    }
    bustia.cues[bustia.numCues].idCua = cuaID;
    bustia.cues[bustia.numCues].keyCua = key;
    bustia.cues[bustia.numCues++].idFile = idFile;
    return cuaID;
}

// Función para eliminar una cola de mensajes
void eliminarCola(int cuaID) {
    if (msgctl(cuaID, IPC_RMID, NULL) == -1) {
        perror("Error al eliminar la cola de mensajes");
    }
    int i = 0;
    while(i<bustia.numCues){
        if (bustia.cues[i].idCua == cuaID){
            bustia.cues[i].idCua = -1;
            bustia.cues[i].keyCua = (key_t) 0;
            bustia.numCues--;
            break;
        }
        i++;
    }

}

// Función para obtener el ID de cola por el identificador del flujo
int obtenerColaPorId(int idFile ) {
    for (int i = 0; i < bustia.numCues; i++) {
        if (bustia.cues[i].idFile == idFile) { // Suponemos que el idFlujo es igual al key de la cola
            return bustia.cues[i].idCua;
        }
    }
    return -1; // Si no se encuentra una cola existente para el flujo
}

void get_MD5SUM(char *md5sum, char *path) {
    int fd[2];
    pipe(fd);

    pid_t pid = fork();
    if (pid == 0) {
        close(fd[0]);
        dup2(fd[1], STDOUT_FILENO);
        char *args[] = {"md5sum", path, NULL};
        execvp(args[0], args);
        raise(SIGINT);
    } else {
        close(fd[1]);
        wait(NULL);
        read(fd[0], md5sum, 32);
        md5sum[32] = '\0';
        close(fd[0]);
    }
}


char *read_until(int fd, char end){
    int i = 0, size;
    char c = '\0';
    char *string = (char *)malloc(sizeof(char));
 
    while (1) {
        size = read(fd, &c, sizeof(char));

        if (c == end || size <= 0) {
            break;
        } else if (c != '\n' && c != '\r') { // Ignorar saltos de línea y retornos de carro
            string = realloc(string, sizeof(char) * (i + 2));
            string[i++] = c;
        }
    }
    string[i] = '\0';

    return string;
}

Library LIBRARY_create_library() {
    Library library;
    char *buffer;
    char *string;
    write(1, "Quantes cançons tens? ", strlen("Quantes cançons tens? "));
    buffer = read_until(0, '\n');
    library.numSongs = atoi(buffer);
    free(buffer);

    library.songs = malloc(sizeof(Song) * library.numSongs);

    for (int i = 0; i < library.numSongs; i++) {
        /*write(1, "Nom de la canço: ", strlen("Nom de la canço: "));
        buffer = read_until(0, '\n');
        library.songs[i].songName = malloc(strlen(buffer) + 1);
        library.songs[i].songName[strlen(buffer)+1] = '\0';
        strcpy(library.songs[i].songName, buffer);
        free(buffer);*/
            write(1, "Nom de la canço: ", strlen("Nom de la canço: "));
            buffer = read_until(0, '\n');
            library.songs[i].songName = malloc(strlen(buffer) + 1); // +1 para el '\0'
            strcpy(library.songs[i].songName, buffer); // strcpy añade '\0' automáticamente
            free(buffer);
            asprintf(&string,"\nLen %ld\n",strlen(library.songs[i].songName));
            write(1,string,strlen(string));
            free(string);
            write(1, "ID de la canço: ", strlen("ID de la canço: "));
            buffer = read_until(0, '\n');
            library.songs[i].idFile = atoi(buffer); // +1 para el '\0'
            free(buffer);
            
        write(1, "Numero de playlist a les que pertany la canço: ", strlen("Numero de playlist a les que pertany la canço: "));
        buffer = read_until(0, '\n');
        library.songs[i].numPlaylists = atoi(buffer);
        free(buffer);

        if (library.songs[i].numPlaylists > 0) {
            library.songs[i].playlists = malloc(sizeof(char*) * library.songs[i].numPlaylists);
        } else {
            library.songs[i].playlists = NULL;
        }

        for (int j = 0; j < library.songs[i].numPlaylists; j++) {
            write(1, "Nom de la playlist: ", strlen("Nom de la playlist: "));
            buffer = read_until(0, '\n');
            library.songs[i].playlists[j] = malloc(strlen(buffer) + 1);
            strcpy(library.songs[i].playlists[j], buffer);
            free(buffer);
        }
        

    }

    write(1, "Quantes llistes tens? ", strlen("Quantes llistes tens? "));
    buffer = read_until(0, '\n');
    library.numPlaylists = atoi(buffer);
    free(buffer);

    library.playlists = malloc(sizeof(Playlist) * library.numPlaylists);

    for (int i = 0; i < library.numPlaylists; i++) {
        write(1, "Nom de la llista: ", strlen("Nom de la llista: "));
        buffer = read_until(0, '\n');
        library.playlists[i].playlistName = malloc(strlen(buffer) + 1);
        strcpy(library.playlists[i].playlistName, buffer);
        free(buffer);

        write(1, "Numero de cançons que conte la llista: ", strlen("Numero de cançons que conte la llista: "));
        buffer = read_until(0, '\n');
        library.playlists[i].numSongs = atoi(buffer);
        free(buffer);

        if (library.playlists[i].numSongs > 0) {
            library.playlists[i].songs = malloc(sizeof(Song) * library.playlists[i].numSongs);
        } else {
            library.songs[i].playlists = NULL;
        }

        for (int j = 0; j < library.playlists[i].numSongs; j++) {
            write(1, "Nom de la canço: ", strlen("Nom de la canço: "));
            buffer = read_until(0, '\n');
            library.playlists[i].songs[j].songName =  malloc(strlen(buffer) + 1);
            strcpy(library.playlists[i].songs[j].songName, buffer);
free(buffer);
            write(1, "ID de la canço: ", strlen("ID de la canço: "));
            buffer = read_until(0, '\n');
            library.playlists[i].songs[j].idFile = atoi(buffer); // +1 para el '\0'
            free(buffer);
            library.playlists[i].songs[j].numPlaylists = 0;
            library.playlists[i].songs[j].playlists = NULL;
        }
    }

    return library;
}

void LIBRARY_save_file(int fd, Library library) {
    char *string;//debug
    write(fd, &library.numSongs, sizeof(int));

    for (int i = 0; i < library.numSongs; i++) {
        int nameLen = strlen(library.songs[i].songName) + 1;
        write(fd, &nameLen, sizeof(int));
        write(fd, library.songs[i].songName, nameLen);
write(fd, &library.songs[i].idFile, sizeof(int));
        asprintf(&string,"SAVE_FILE songLen %d\n",nameLen);//debug
        write(1,string,strlen(string));//debug
        free(string); //debug
        write(fd, &library.songs[i].numPlaylists, sizeof(int));

        for (int j = 0; j < library.songs[i].numPlaylists; j++) {
            int playlistLen = strlen(library.songs[i].playlists[j]) + 1;
            write(fd, &playlistLen, sizeof(int));
            write(fd, library.songs[i].playlists[j], playlistLen);
        }
    }
    write(fd, &library.numPlaylists, sizeof(int));

    for (int i = 0; i < library.numPlaylists; i++) {
        int nameLen = strlen(library.playlists[i].playlistName) + 1;
        write(fd, &nameLen, sizeof(int));
        write(fd, library.playlists[i].playlistName, nameLen);

        write(fd, &library.playlists[i].numSongs, sizeof(int));

        for (int j = 0; j < library.playlists[i].numSongs; j++) {
            int playlistLen = strlen(library.playlists[i].songs[j].songName) + 1;
            write(fd, &playlistLen, sizeof(int));
            write(fd, library.playlists[i].songs[j].songName, playlistLen);
write(fd, &library.playlists[i].songs[j].idFile, sizeof(int));

        }
    }
}

Library LIBRARY_read_file(char* fielPath) {

    int fd = open(fielPath, O_RDONLY);
    Library library;
    char *string;
    printf("Num bytes: %d\n", (int) read(fd, &library.numSongs, sizeof(int)));
    library.songs = malloc(sizeof(Song) * library.numSongs);
    int nameLen;
    int playlistLen;
    int songLen;
    for (int i = 0; i < library.numSongs; i++) {
        read(fd, &nameLen, sizeof(int));
        library.songs[i].songName = malloc(nameLen);
        read(fd, library.songs[i].songName, nameLen);
read(fd, &library.songs[i].idFile, sizeof(int));

        read(fd, &library.songs[i].numPlaylists, sizeof(int));
        asprintf(&string,"\nNum playlists = %d\n",library.songs[i].numPlaylists);
        write(1,string,strlen(string));
        free(string);
        library.songs[i].playlists = malloc(sizeof(char*) * library.songs[i].numPlaylists);
        for (int j = 0; j < library.songs[i].numPlaylists; j++) {
            read(fd, &playlistLen, sizeof(int));
            library.songs[i].playlists[j] = malloc(playlistLen);
            read(fd, library.songs[i].playlists[j], playlistLen);
        }
    }
    printf("Num bytes: %d\n", (int) read(fd, &library.numPlaylists, sizeof(int)));
    library.playlists = malloc(sizeof(Playlist) * library.numPlaylists);
    for (int i = 0; i < library.numPlaylists; i++) {
        read(fd, &nameLen, sizeof(int));
        library.playlists[i].playlistName = malloc(nameLen);
        read(fd, library.playlists[i].playlistName, nameLen);

        read(fd, &library.playlists[i].numSongs, sizeof(int));
        asprintf(&string,"\nP[%d]Num songs = %d\n",i,library.playlists[i].numSongs);
        write(1,string,strlen(string));
        free(string);
        library.playlists[i].songs = malloc(sizeof(Song*) * library.playlists[i].numSongs);
        for (int j = 0; j < library.playlists[i].numSongs; j++) {
            read(fd, &songLen, sizeof(int));

            library.playlists[i].songs[j].songName = malloc(songLen);
            read(fd, library.playlists[i].songs[j].songName, songLen);
read(fd, &library.playlists[i].songs[j].idFile, sizeof(int));

            asprintf(&string,"\nP[%d]Name song[%d] = %s[%ld]\n",i,j,library.playlists[i].songs[j].songName,strlen(library.playlists[i].songs[j].songName));
            write(1,string,strlen(string));
            free(string);
        }
    }
    close(fd);

    return library;
}

void **SongDataGenerator(Library library, int *numBytesACC) {
    char **data;
    char *string;
    int songsLen = 0;
    int numBytesUtils = 0 ;
    
    for (int i = 0; i < library.numSongs; i++) {
        songsLen += strlen(library.songs[i].songName) ; 
        asprintf(&string,"numDataStrings = %d\n",songsLen);
        write(1,string,strlen(string));
        free(string);
        
    }
    char *numBytes;
    asprintf(&numBytes,"%d",songsLen);
    int numCharBytes = numCharBytes = strlen(numBytes);
    free(numBytes);
    
    int numDataStrings = songsLen / (songDataSize - numCharBytes ) + (songsLen % (songDataSize - numCharBytes ) != 0);
    asprintf(&string,"numDataStrings = %d\n",numDataStrings);
    write(1,string,strlen(string));
    free(string);
    data = malloc(sizeof(char*) * (numDataStrings + 1)); 
    for (int i = 0, songPos = 0; i < numDataStrings; i++) {
        data[i] = malloc((songDataSize - numCharBytes ));
        int stringPos = 0;

        while (songPos < library.numSongs && stringPos < ((songDataSize - numCharBytes ) - 1)) { 
            char *songName = library.songs[songPos].songName;
            int songNameLength = strlen(songName);
            
            
            if (stringPos + songNameLength < ((songDataSize - numCharBytes ) - 1)) {
                strcpy(data[i] + stringPos, songName);
                stringPos += songNameLength;
                numBytesUtils += songNameLength-1;

                
                if (songPos < library.numSongs - 1 && stringPos < ((songDataSize - numCharBytes ) - 1)) {
                    data[i][stringPos] = '&';
                    stringPos++;
                    numBytesUtils++;
                }
            } else {
                break; 
            }
            songPos++;
        }


        // Rellenar el resto con '\0'
        char a ;
        for (int j = stringPos; j < (songDataSize - numCharBytes ); j++) {
            data[i][j] = '\0';
        }
        for(int j = 0; j<(songDataSize - numCharBytes );j++){
            if(data[i][j]=='\0'){

            write(1,"-",1);
            }else{
                a = data[i][j];
                write(1,&a,1);
            }
        }
        
    }

    data[numDataStrings] = NULL; 
    *numBytesACC = numBytesUtils;
    return (void**)data;
}
void **PlaylistDataGenerator(Library library, int *numBytesACC) {
    char **data;
    char *string;
    int totalBytes = 0;

    for (int i = 0; i < library.numPlaylists; i++) {
        totalBytes += strlen(library.playlists[i].playlistName); 
        for (int j = 0; j < library.playlists[i].numSongs; j++) {
            totalBytes += strlen(library.playlists[i].songs[j].songName); 
        } 
    }

    int numDataStrings = totalBytes / 230 + (totalBytes % 230 != 0);
    *numBytesACC = 0;
    data = malloc(sizeof(char*) * (numDataStrings + 1));

    for (int i = 0, playlistPos = 0; i < numDataStrings; i++) {
        data[i] = malloc(230);
        int stringPos = 0;
        while (playlistPos < library.numPlaylists && stringPos < 229) {

            int stringAddLength = strlen(library.playlists[playlistPos].playlistName);
            
            for(int j = 0; j < library.playlists[playlistPos].numSongs;j++){
                stringAddLength += strlen(library.playlists[playlistPos].songs[j].songName);
            }
            char *playlistName = library.playlists[playlistPos].playlistName;
            int playlistLength = strlen(playlistName);
            if (stringPos + stringAddLength < 229) {
                strcpy(data[i] + stringPos, playlistName);
                stringPos += playlistLength;
                *numBytesACC += playlistLength - 1;

                for (int j = 0; j < library.playlists[playlistPos].numSongs ; j++) {
                    const char *songName = library.playlists[playlistPos].songs[j].songName;
                    int songNameLength = strlen(songName);

                    data[i][stringPos++] = '&';
                    strcpy(data[i] + stringPos, songName);
                    stringPos += songNameLength;
                    *numBytesACC += songNameLength;
                    
                }

                if (playlistPos < library.numPlaylists - 1 && stringPos < 229) {
                    data[i][stringPos++] = '#';
                    *numBytesACC += 1;
                }
            } else {
                break;
            }
            playlistPos++;
        }

        for (int j = stringPos; j < 230; j++) {
            data[i][j] = '\0';
        }
        write(1,data[i],230);
        asprintf(&string,"\nnumDataStrings = %d\n",i);
        write(1,string,strlen(string));
        free(string);   
        write(1,"\n",1);
    }

    data[numDataStrings] = NULL;
    return (void**)data;
}
Plot plotReader(int fd)
{
    Plot plot;

    write(1, "\nTRAMA LLEGIDA: \n", strlen("\nTRAMA LLEGIDA: \n"));//debugg
plot.type = 0;
    plot.HEADER_LENGTH = 2;
    plot.HEADER = NULL;
    plot.data = NULL;
    read(fd, &(plot.type), 1);
    

    read(fd, &(plot.HEADER_LENGTH), 2);
    /*char *buffer;//debug
    asprintf(&buffer, "Header length: %d\n", plot.HEADER_LENGTH);//debug
    write(1, buffer, strlen(buffer));//debugg
    free(buffer);//debug
    */
    plot.HEADER = malloc(plot.HEADER_LENGTH);
    
    int numBytes;
    numBytes = read(fd, plot.HEADER, plot.HEADER_LENGTH);

    plot.HEADER[numBytes] = '\0'; //------------------------------------------------------becaris debug
/*
    write(1, "Header: ", strlen("Header: "));//debugg
    write(1, plot.HEADER, strlen(plot.HEADER));//debugg
    write(1, "\n", strlen("\n"));//debugg
*/
    plot.data = malloc(256 - 3 - plot.HEADER_LENGTH);
    read(fd, plot.data, (256 - 3 - plot.HEADER_LENGTH));
    //write(1, "Data: ", strlen("Data: "));//debugg
    
    
    /*asprintf(&buffer, "Data length: %d\n", (int) strlen(plot.data));//debug
    write(1, buffer, strlen(buffer));//debugg
    free(buffer);//debug
*/
    
        
     
    return plot;
}

void* plotGenerator(char type, char *Header, void **data, int numDades, int *dataSize)
{
    //char *string;//debugg
    //write(1, "\nTRAMA GENERADA: \n", strlen("\nTRAMA GENERADA: \n"));//debug
    int debug_data_len = 0;
    char *plotString = malloc(256);
    int posPlot = 0;

    plotString[posPlot] = type;
    posPlot++;

    //asprintf(&string, "Type: %c\n", type);//debugg
    //write(1, string, strlen(string));//debug
    //free(string);

    short header_length = strlen(Header);
    
    plotString[posPlot] = (char) (header_length & 0xff);
    posPlot++;
    
    plotString[posPlot] = (char) ((header_length >> 8) & 0xff);
    posPlot++;

    //asprintf(&string, "Header length: %d\n", (int) header_length);//debugg
    //write(1, string, strlen(string));//debug
    //free(string);
   
    int i = 0;
    while(header_length > i)
    {
        plotString[posPlot] = Header[i];
       
        posPlot++;
        i++;
    }
    //asprintf(&string, "Header: %s\n", Header);//debugg
    //write(1, string, strlen(string));//debug
    //free(string);
        
    //write(1, "Data: [", strlen("Data: ["));//debug
    
    debug_data_len = posPlot;
    if(data != NULL)
    {
        //int data_length = 0; //debug
        char **buffer;
        buffer = (char**) data;

        i = 0;
        int n;
        while(i<numDades)
        {
            n = 0;
            while(dataSize[i] > n)
            {   
                plotString[posPlot] = buffer[i][n];
                posPlot++;
                // data_length++;//debugg
                n++;
            }
            debug_data_len = posPlot - debug_data_len;

            // for(int x = 0; x<244;x++){//debug
                //    if(buffer[i][x]=='\0'){
                
                //    write(1,"-",1);//debug
                //   }else{//debug
                    //        char *a = (char*) malloc(sizeof(char));//debug
                    //         *a = buffer[i][x];//debug
                    //        write(1,a,1);//debug
                //       }
          //  }//debug
            //write(1, buffer[i], dataSize[i]); //debug
            plotString[posPlot] = '&';
            // data_length++;//debug
            posPlot++;
            i++;
        }
        plotString[posPlot - 1] = '\0'; 
    }else{
        plotString[posPlot] = '\0';
        posPlot++;
    }
    //write(1, "]\n", strlen("]\n"));//debug
    //asprintf(&string, "\nDataLen = %d\n", debug_data_len);//debugg
    //write(1, string, strlen(string));//debug
    //free(string);
    
    if(posPlot < 256)
    {
        i = 0;
        while(posPlot < 256)
        {
            plotString[posPlot] = '\0';
            posPlot++;
        }
    }
    return plotString;
}
void **Mp3DataGenerator(char *fileName,int id) {

    int fd = open(fileName, O_RDONLY);
    if (fd < 0) {
        perror("Error opening file");
        return NULL;
    }


    char **data = malloc(sizeof(char*) * 2);
    int i = 1, totalBytes = 0, nByte;
    char *idChar;
    asprintf(&idChar, "%d", id);
    data[i] = malloc(downloadDataSize - (strlen(idChar) + 1));  
int k;
    for(k = 0; k < (int) strlen(idChar);k++){
        data[i][k] = idChar[k];
    }
    data[i][k] = '&';
    //int debug_numDataEscrita;//debug
    while (1) {
        int j = strlen(idChar) + 1 ;
        while (j < (int) (downloadDataSize - (strlen(idChar) + 1))) {
            nByte = read(fd, &data[i][j], 1);
            if (nByte <= 0) break;  
            totalBytes++;
            j++;
        }

        if (nByte <= 0) {
            while (j < (int) (downloadDataSize - (strlen(idChar) + 1))) {
                data[i][j++] = '\0';
            }

            i++;
            data = realloc(data, sizeof(char*) * (i + 1));
            data[i] = NULL;  

            //debug_numDataEscrita = j;
            break;
        } else {
            i++;
            data = realloc(data, sizeof(char*) * (i + 1));
            data[i] = malloc((downloadDataSize - (strlen(idChar) + 1)));
            int k;
            for( k = 0; k < (int) strlen(idChar);k++){
                data[i][k] = idChar[k];
            }
            data[i][k] = '&';
        }
    }
    char *string;
    asprintf(&string,"\n\n\n\n\n%d\n%d\n\n\n\n\n\nDATA[%d] = [%s]\n",i,totalBytes,i,data[138]);//debug
            write(1,string,strlen(string));
            free(string);
    
    for(int x = 0; x<244;x++){//debug
        if(data[138][x]=='\0'){
        
        write(1,"-",1);//debug
        }else{//debug
            char *a = (char*) malloc(sizeof(char));//debug
            *a = data[138][x];//debug
            write(1,a,1);//debug
        }
    }//debug
    char md5sum[32];
    get_MD5SUM(md5sum,fileName);
        asprintf(&string,"%s&%d&%s&%d",fileName,totalBytes,md5sum,id);
write(1,string,strlen(string));
    sleep(2);
    int j = strlen(string);

    data[0] = strdup(string);
    data[0] = realloc(data[0],downloadDataSize + 1);
    while (j < downloadDataSize + 1) {
        data[0][j++]= '\0';
    }


    free(string);
    close(fd);
    
    /*for (int i = 0; data[i]!=NULL; i++){//debug
        //write(1,"\nData = [",strlen("\nData = ["));//debug
        asprintf(&string,"\nData[%d] = ",debug_numDataEscrita);//debug
        write(1,string,strlen(string));//debug
        free(string);//debug
        for(int x=0;x<debug_numDataEscrita;x++){
            if(data[i][x]=='\0'){//debug
            write(1,"-",1);//debug
            }else{//debug
                char *a = (char*) malloc(sizeof(char));//debug
                *a = data[i][x];//debug
                write(1,a,1);//debug
            }
        }
        write(1,"]\n",strlen("]\n"));//debug
    }*/
    
    return (void**) data;
}

void *server_function() {
    int server_fd, new_socket;
    struct sockaddr_in s_addr;
    int addrlen = sizeof(s_addr);

    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0) {
        fprintf(stderr, "ERROR: Socket failed: %s\n", strerror(errno));
    }

    s_addr.sin_family = AF_INET;
    s_addr.sin_port = htons(8295);
    s_addr.sin_addr.s_addr = htonl(INADDR_ANY);

    if (bind(server_fd, (struct sockaddr *)&s_addr, sizeof(s_addr)) < 0) {
        fprintf(stderr, "ERROR: Bind failed: %s\n", strerror(errno));
        close(server_fd);
    }

    if (listen(server_fd, 3) < 0) {
        fprintf(stderr, "ERROR: Listen failed: %s\n", strerror(errno));
        close(server_fd);
    }
    write(1,"\nS: waiting for connection\n",strlen("\nS: waiting for connection\n"));
    
    if ((new_socket = accept(server_fd, (struct sockaddr *)&s_addr, (socklen_t*)&addrlen)) < 0) {
        fprintf(stderr, "ERROR: Accept failed: %s\n", strerror(errno));
        close(server_fd);
    }
    write(1,"\nS: connected\n",strlen("\nS: connected\n"));


    char *plotString;
    char **dataStrings_1;
    char **dataStrings_2;
    //char *string;
    int i = 0;
    dataStrings_1 = (char **) Mp3DataGenerator("audio.mp3",5);   //numTotalbyte, cambiar?????
    dataStrings_2 = (char **) Mp3DataGenerator("audio2.mp3",12);   //numTotalbyte, cambiar?????

    /*int fd_prova = open("data.mp3",O_WRONLY | O_CREAT | O_TRUNC, 0644);
    i = 1;
    while(dataStrings[i]!=NULL){ 

        write(fd_prova,dataStrings[i++],244);

    }
    close(fd_prova);
    */
    i = 0;

    int dataStringLength_1;
    int dataStringLength_2;
    dataStringLength_1 = 244;
    dataStringLength_2 = 244;
    //write(1,"\n---Trama Info---\n",strlen("\n---Trama Info---\n"));
    //asprintf(&string,"Data[0] =  %s\n",dataStrings[0]);
    //write(1,string,strlen(string));
    //free(string);
    plotString = plotGenerator(0x04, "NEW_FILE", (void **)&(dataStrings_1[i]), 1, &dataStringLength_1);
    write(new_socket,plotString,256);
    plotString = plotGenerator(0x04, "NEW_FILE", (void **)&(dataStrings_2[i]), 1, &dataStringLength_2);
    write(new_socket,plotString,256);
    //write(1,"\n---Fi Info---\n",strlen("\n---Fi Info---\n"));
    
    //write(fdBowman, plotString, 256);
    
    free(plotString);
    i++;
    while(dataStrings_1[i] != NULL){  
        
        //write(1,"\n---Trama Data---\n",strlen("\n---Trama Data---\n"));
        plotString = plotGenerator(0x04, "FILE_DATA", (void **)&(dataStrings_1[i]), 1, &dataStringLength_1);
        write(new_socket,plotString,256);
        //write(1,"\n---Fi Data---\n",strlen("\n---Fi Data---\n"));
        free(plotString);        
        i++;
    }
    i=1;
    while(dataStrings_2[i] != NULL){  
        
        //write(1,"\n---Trama Data---\n",strlen("\n---Trama Data---\n"));
        plotString = plotGenerator(0x04, "FILE_DATA", (void **)&(dataStrings_2[i]), 1, &dataStringLength_2);
        write(new_socket,plotString,256);
        //write(1,"\n---Fi Data---\n",strlen("\n---Fi Data---\n"));
        free(plotString);        
        i++;
    }
    //int id = msgget(ftok("audio.mp3", 'A'), 0600 | IPC_CREAT);

    
    while (1)
    {
        
    
    }
    
   

    close(new_socket);
    close(server_fd);
    return NULL;
}


void *read_function(){
    char *string;
    int port = 8295;
    char *ipString = "192.168.1.5";
    int fdsocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (fdsocket < 0) {
        fprintf(stderr, "ERROR: Socket not created: %s\n", strerror(errno));
        
    }

    struct sockaddr_in s_addr;
    bzero(&s_addr, sizeof(s_addr));
    s_addr.sin_family = AF_INET;
    s_addr.sin_port = htons(port);
    
    if (inet_aton(ipString, &s_addr.sin_addr) == 0) {
        fprintf(stderr, "ERROR: IP is not valid: %s\n", strerror(errno));
    }
    sleep(5);
    if (connect(fdsocket, (struct sockaddr *)&s_addr, sizeof(s_addr)) < 0) {
        fprintf(stderr, "ERROR: Connection error: %s\n", strerror(errno));
        close(fdsocket);
    }

    write(1,"\nR: connected\n",strlen("\nR: connected\n"));
    int i=1;
    crearCola(0,0);
    
    while(1){

        Plot plot = plotReader(fdsocket);
        int idCua;
        if(strcmp(plot.HEADER,"NEW_FILE")==0 ){
            write(1,"\nR: NEW_FILE\n",strlen("\nR: NEW_FILE\n"));

            char *songName = getSongNameFromPlot(plot);
            int idFile = getIdFromPlotNEW(plot);
            key_t key = ftok(songName,'A');
            idCua = crearCola(key,idFile);
            
        }else if (strcmp(plot.HEADER,"FILE_DATA") == 0){
            write(1,"\nR: FILE_DATA\n",strlen("\nR: FILE_DATA\n"));
            int idFile = getIdFromPlotDATA(plot);
            
            idCua = obtenerColaPorId(idFile);
            asprintf(&string,"Per idFile = %d idCua = %d \n",idFile,idCua);
            write(1,string,strlen(string));
            free(string);
            
        }else{
            write(1,"\nR: COMMAND\n",strlen("\nR: COMMAND\n"));
            idCua = 0;
        }

        MensajeCola mensaje;
        mensaje.idFlux = i;  // Usar el identificador del flujo como tipo de mensaje
        mensaje.plot = plot;
        asprintf(&string,"idCua = %d amb idFlux %ld\n",idCua,mensaje.idFlux);
        write(1,string,strlen(string));
        free(string);
        string = strndup(mensaje.plot.data,4);
        asprintf(&string,"mensaje.plot = [%s]\n",mensaje.plot.data);
        write(1,string,strlen(string));
        free(string);
        // Enviar el mensaje a la cola correspondiente
        perror("Perror abans de msgsend no fos que pasialgo altre\n");
        if (msgsnd(idCua, (void *)&mensaje, sizeof(Plot), 0) == -1) {
            perror("msgsnd falló");
            while (1)
            {     }
        }else {
            write(1,"msg enviat\n",strlen("msg enviat\n"));
        }
        
        
    }

    
    

}
int main()
{   
    
   

    
    

    Library llibreria;

    llibreria = LIBRARY_create_library();

    int fd = open("patata.dat", O_CREAT | O_WRONLY | O_TRUNC, S_IWUSR | S_IRUSR | S_IWGRP | S_IRGRP | S_IWOTH | S_IROTH);

    printf("File descriptor: %d\n", fd);

    LIBRARY_save_file(fd, llibreria);
    close(fd);



    Library library = LIBRARY_read_file("patata.dat");
    char *string;
    asprintf(&string,"numSongs = %d\n",library.numSongs);
    write(1,string,strlen(string));
    free(string);

    write(1, "\n", 1);

    for (int i = 0; i < library.numSongs; i++) {
        asprintf(&string,"Nom canço: %s-%d\nIdFile = %d\n",library.songs[i].songName,(int)strlen(library.songs[i].songName),library.songs[i].idFile);
        write(1,string,strlen(string));
        free(string);

        for (int j = 0; j < library.songs[i].numPlaylists; j++) {
            int playlistLen = strlen(library.songs[i].playlists[j]) + 1;
            write(1, "Nom playList: ", strlen("Nom playList: "));
            write(1, library.songs[i].playlists[j], playlistLen);
            write(1, "-", 1);
            write(1, "\n", 1);

        }
    }
    for (int i = 0; i < library.numPlaylists; i++) {
        asprintf(&string,"Nom playlist: %s-%d\n",library.playlists[i].playlistName,(int)strlen(library.playlists[i].playlistName));
        write(1,string,strlen(string));
        free(string);

        for (int j = 0; j < library.playlists[i].numSongs; j++) {
            //int playlistLen = strlen(library.playlists[i].songs[j].songName) + 1;
            asprintf(&string,"Nom canço: %s-%d\nIdFile = %d\n",library.playlists[i].songs[j].songName,(int)strlen(library.playlists[i].songs[j].songName),library.playlists[i].songs[j].idFile);
            write(1,string,strlen(string));
            free(string);

        }
    }

    write(1, "\n", 1);
    write(1, "\n", 1);
    write(1, "\n", 1);
    write(1, "\n", 1);
    write(1, "\n", 1);
    write(1, "\n", 1);

    /*
    pthread_t server_thread;
    pthread_create(&server_thread, NULL, server_function, NULL);
    pthread_t read_thread;
    pthread_create(&read_thread, NULL, read_function, NULL);
    */
    //freeTheData((void**) dataStrings);
/*

    int i = 0;
    int n = 0;
    char **data1 = (char **) SongDataGenerator(library,&n);
    for(i=0;i<235;i++){
        if(data1[0][i]=='\0'){
            
            write(1,"-",1);
        }else{
            char *a = (char*) malloc(sizeof(char));
            *a = data1[0][i];
            write(1,a,1);

        }
    }
    asprintf(&string,"lenData = %d\n",(int)strlen(data1[0]));
    write(1,string,strlen(string));
    free(string);
    
    i = 0;
    n = 0;
    
    char **data2 = (char **) PlaylistDataGenerator(library,&n);
    write(1,"\n",1);
    write(1,"\n",1);
    write(1,"\n",1);
    write(1,"\n",1);
    while(data2[i]!= NULL){
        for(int j = 0; j<230;j++){
            if(data2[i][j]=='\0'){
            
            write(1,"-",1);
            }else{
                char *a = (char*) malloc(sizeof(char));
                *a = data2[i][j];
                write(1,a,1);
            }
        }
        i++;
    }
    
    char **data3 = (char **)Mp3DataGenerator(argv[argc - 1]);
    
    int i = 0;
    write(1,"\n\n\n\n-----------------------------------------------------\n\n\n\n",strlen("\n\n\n\n-----------------------------------------------------\n\n\n\n"));
    while(data3[i]!= NULL){
        for(int j = 0; j<235;j++){
            if(data[i][j]=='\0'){
            
            write(1,"-",1);
            }else{
                char *a = (char*) malloc(sizeof(char));
                *a = data[i][j];
                write(1,a,1);
            }
        }
        i++;
    }
    */
//pthread_join(read_thread,NULL);
    return 0;
}


/*

2
audio_1
1
2
Playlist_1
Playlist_2
audio_2
2
2
Playlist_2
Playlist_3
3
Playlist_1
1
audio_1
1
Playlist_2
2
audio_1
1
audio_2
2
Playlist 3
1
audio_2
2


*/



