#ifndef STRINGS_H
#define STRINGS_H

char *read_until(int fd, char end);

#endif