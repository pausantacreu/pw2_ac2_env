
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <string.h>


char *read_until(int fd, char end){
    char *string = NULL;
    int i = 0, size;
    char c = '\0';
    while (1)
    {
        size = read(fd, &c, sizeof(char));

        if (c != end && size > 0){

            string = (char *)realloc(string, sizeof(char) * (i + 2));
            string[i++] = c;

        }else{
            break;
        }
    }
    if(string!=NULL)string[i] = '\0';
    return string;
}

