#define _GNU_SOURCE
#include "../Libraries/Semaphore/semaphore_v2.h"
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <stdlib.h>
#include <signal.h>
#include <errno.h>
#include <sys/wait.h>
#include <time.h>
#include <math.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include <sys/msg.h>
#include <pthread.h>


#include "../Libraries/Files/files.h"
#include "../Libraries/Strings/strings.h"
#include "../Libraries/Trames/Trames.h"
#include "../Libraries/Sockets/Sockets.h"
#include "../Libraries/Library/Library.h"
#include "../Libraries/Cues/Cues.h"



//------------------------------START DEFINITIONS--------------------------------------
#define ID_ERROR -1
#define ID_NO_MATCH 0
#define ID_CONNECT 1
#define ID_LOGOUT 2
#define ID_LIST_SONGS 3
#define ID_LIST_PLAYLISTS 4
#define ID_DOWNLOAD 5
#define ID_CHECK_DOWNLOADS 6
#define ID_CLEAR_DOWNLOADS 7

#define STRING_CONNECT "CONNECT"
#define STRING_LOGOUT "LOGOUT"
#define STRING_LIST_SONGS "LIST SONGS"
#define STRING_LIST_PLAYLISTS "LIST PLAYLISTS"
#define STRING_DOWNLOAD "DOWNLOAD "
#define STRING_DOWNLOAD_SONG ".mp3"
#define STRING_CHECK_DOWNLOADS "CHECK DOWNLOADS"
#define STRING_CLEAR_DOWNLOADS "CLEAR DOWNLOADS"
#define CONNECTED 1
#define TRUE 1
#define FALSE 0

#define OPTION_SONG 0
#define OPTION_PLAYLISTS 1 

#define TYPE_0x01 0x01
#define TYPE_0x02 0x02
#define TYPE_0x03 0x03
#define TYPE_0x04 0x04
#define TYPE_0x05 0x05
#define TYPE_0x06 0x06
#define TYPE_0x07 0x07

//send headers
#define HEADER_NEW_BOWMAN "NEW_BOWMAN"
#define HEADER_DELETE_BOWMAN "DELETE_BOWMAN"
#define HEADER_LIST_SONGS "LIST_SONGS"
#define HEADER_LIST_PLAYLISTS "LIST_PLAYLISTS"
#define HEADER_DOWNLOAD_SONG "DOWNLOAD_SONG"
#define HEADER_DOWNLOAD_LIST "DOWNLOAD_LIST"
#define HEADER_CHECK_OK "CHECK_OK"
#define HEADER_CHECK_KO "CHECK_KO"
#define HEADER_EXIT "EXIT"
#define HEADER_UNKNOWN "UNKNOWN"

//receive headers
#define HEADER_CON_OK "CON_OK"
#define HEADER_CON_KO "CON_KO"
#define HEADER_SONGS_RESPONSE "SONGS_RESPONSE"
#define HEADER_PLAYLISTS_RESPONSE "PLAYLISTS_RESPONSE"
#define HEADER_NEW_FILE "NEW_FILE"
#define HEADER_FILE_DATA "FILE_DATA"



//------------------------------END DEFINITIONS----------------------------------------

void FreeTheMalloc();
void *bowmanQueueMessasgeReader();
void *bowmanSocketMessageReader();

//-------------------------------START STRUCTS------------------------------------------------------

typedef struct _bowman{
    char *user_name;
    char *user_path;
    char *discovery_ip;
    int discovery_port;
    char *server_name;
    char *poole_ip;
    int poole_port;
    int fdPoole;
    pthread_t *readerThreadsID;
}Bowman;

typedef struct {
    int *downloadPercentage;
    char **fileName;
    int numDownloads;
}Downloads;




//----Global variables--------
Bowman bowman;
Cues bustia;
Downloads downloads;

//-------------------------------END STRUCTS------------------------------------------------------

//-------------------------------END Input//Output Functions------------------------------------------------------
//-------------------------------START Read File Functions------------------------------------------------------


//-------------------------------START CONNECTIONS------------------------------------------------------

int Handle_Discovery_Bowman(int fdDiscoverySocket){
    int i;
    Plot plot = plotReader(fdDiscoverySocket);

    if((plot.type == TYPE_0x01) && ((size_t) plot.HEADER_LENGTH == strlen(plot.HEADER)) && (strcmp(HEADER_CON_OK,plot.HEADER) == 0) && (strlen(plot.data) > 0)){
        char *buffer;
        buffer = strtok(plot.data, "&");
        bowman.server_name = realloc(bowman.server_name , strlen(buffer) + 1);
        strcpy(bowman.server_name,buffer);

        buffer = strtok(NULL, "&");
        bowman.poole_ip = realloc(bowman.poole_ip , strlen(buffer) + 1);
        strcpy(bowman.poole_ip, buffer);

        bowman.poole_port = byteToInteger(strtok(NULL, "&"));
        i = 0;
    }else if((plot.type == TYPE_0x06) && ((size_t) plot.HEADER_LENGTH == strlen(plot.HEADER)) && (strcmp(HEADER_CON_OK,plot.HEADER) == 0)){
        write(1, "Disconecting from Discovery...\n", strlen("Disconecting from Discovery...\n"));
        i = 0;
    }else if ((plot.type == TYPE_0x01) && ((size_t) plot.HEADER_LENGTH == strlen(plot.HEADER)) && (strcmp(HEADER_CON_KO,plot.HEADER) == 0)){
        i = -1;
        write(1, "\nUnable to connect to Discovery...\n", strlen("\nUnable to connect to Discovery...\n"));
    }else{
        i = -1;
        write(1, "\nUnknown command received!!!\n", strlen("\nUnknown command received!!!\n"));
        char *plotString;
        plotString = plotGenerator(TYPE_0x07, HEADER_UNKNOWN, NULL, 0, NULL);
        write(fdDiscoverySocket, plotString, 256);
        free(plotString);
    }
    freePlot(plot);

    return i;
}

//-------------------------------END CONNECTIONS------------------------------------------------------
void readConfig(int fd){
    char *port;
    bowman.user_name = read_until(fd,'\n');
    bowman.user_path = read_until(fd,'\n');
    bowman.discovery_ip = read_until(fd,'\n');
    port = read_until(fd,'\n');
    bowman.discovery_port = atoi(port);
    free(port);
    bowman.server_name = malloc(sizeof(char));
    bowman.poole_ip = malloc(sizeof(char));
    bowman.poole_port = 0;
    bowman.fdPoole = -1;
    bowman.readerThreadsID = malloc(sizeof(pthread_t) * 2);
    bowman.readerThreadsID[0] = 0;
    bowman.readerThreadsID[1] = 0;

    //no poner downloads aqui (pooleConnection)
}
//-------------------------------END Read File Functions------------------------------------------------------
void CheckStringSpaces(char *input){

    int len = strlen(input);
    int i, j;
    int insideWord = 0; 
    for (i = 0, j = 0; i < len; i++) {
        if (input[i] == ' ') {
            if (insideWord) {
                input[j] = ' '; 
                j++;
            }
            insideWord = 0; 
        } else {
            input[j] = input[i]; 
            j++;
            insideWord = 1; 
        }
    }
    input[j] = '\0'; 
    //input = (char*) realloc(input,strlen(input)*sizeof(char));
}

int CheckDownloadCommand(char *input) {
    if (strncasecmp(input, STRING_DOWNLOAD, 9) != 0) {
        return FALSE;
    }
    
    /*char *fileName = input + 9;
    
    int fileLen = strlen(fileName);
    if(strncasecmp(fileName + fileLen - strlen(STRING_DOWNLOAD_SONG), STRING_DOWNLOAD_SONG, strlen(STRING_DOWNLOAD_SONG))==0){
        for (int i = 0; i < fileLen; i++) {
            if (song[i] == ' ') {
                return FALSE;
            }
        }
    }else{
        return FALSE;
    }*/
    
    return TRUE;
}

int ReadChatBuffer(char *input){

    if(strcasecmp(input,STRING_CONNECT)==0){
        return ID_CONNECT;
    }else if(strcasecmp(input,STRING_LOGOUT)==0){
        return ID_LOGOUT;
    }else if(strcasecmp(input,STRING_LIST_SONGS)==0){
        return ID_LIST_SONGS;
    }else if(strcasecmp(input,STRING_LIST_PLAYLISTS)==0){
        return ID_LIST_PLAYLISTS;
    }else if(strcasecmp(input,STRING_CHECK_DOWNLOADS)==0){
        return ID_CHECK_DOWNLOADS;
    }else if(strcasecmp(input,STRING_CLEAR_DOWNLOADS)==0){
        return ID_CLEAR_DOWNLOADS;
    }else if(CheckDownloadCommand(input)==1){
        return ID_DOWNLOAD;
    }else{
        return ID_NO_MATCH;
    }
}

int discoveryConnection()
{
    int fdDiscoverySocket;

    //Conexio discovery
    fdDiscoverySocket  = clientConnection(bowman.discovery_port, bowman.discovery_ip, "DISCOVERY");
    if(fdDiscoverySocket<0){
        FreeTheMalloc();
        exit(-1);
    }
    //Protocol discovery
    void **data;
    data = malloc(sizeof(void*) * 1);
    data[0] = (void*) bowman.user_name;

    int *dataSize;
    dataSize = malloc(sizeof(int));
    dataSize[0] = (int) strlen(bowman.user_name);

    void *plot = plotGenerator(TYPE_0x01,HEADER_NEW_BOWMAN,data,1,dataSize);
    
    write(fdDiscoverySocket,plot,256);
    free(plot);

    write(1, "\nWaiting for Poole data...\n", strlen("\nWaiting for Poole data...\n"));

    int i;
    i = Handle_Discovery_Bowman(fdDiscoverySocket);
    close(fdDiscoverySocket);
    free(dataSize);
    free(data);

    return i;
}

int pooleConnection()
{
    bowman.fdPoole = clientConnection(bowman.poole_port, bowman.poole_ip, "POOLE");

    char *plotString;
    void **data;
    data = malloc(sizeof(void*) * 1);
    data[0] = (void *) bowman.user_name;

    int *dataSize;
    dataSize = malloc(sizeof(int));
    dataSize[0] = (int) strlen(bowman.user_name);

    

    plotString = plotGenerator(TYPE_0x01, HEADER_NEW_BOWMAN, data,1,dataSize);

    write(bowman.fdPoole, plotString, 256);
    free(plotString);
    free(dataSize);
    free(data);

    Plot plot = plotReader(bowman.fdPoole);
    int i;
    if(plot.type == TYPE_0x01 && strcmp(HEADER_CON_OK,plot.HEADER) == 0){//Conexio correcte

        if(bowman.readerThreadsID[0] == 0 && bowman.readerThreadsID[1] == 0){
            write(1, bowman.user_name, strlen(bowman.user_name));
            write(1, " connected to HAL 9000 system, welcome music lover!\n", strlen(" connected to HAL 9000 system, welcome music lover!\n"));
            downloads.downloadPercentage = malloc(sizeof(int));
            downloads.downloadPercentage[0] = 0;
            downloads.fileName = malloc(sizeof(char*));
            downloads.numDownloads = 0;
            pthread_create( &bowman.readerThreadsID[0], NULL, bowmanSocketMessageReader, NULL);
            //pthread_detach(bowman.readerThreadsID[0]);
            pthread_create( &bowman.readerThreadsID[1], NULL, bowmanQueueMessasgeReader, NULL);
            //pthread_detach(bowman.readerThreadsID[1]);
            semaphore printSemaphore;
            SEM_constructor_with_name(&printSemaphore, ftok("Bowman.c", 'B'));
            SEM_signal(&printSemaphore);
        }
        i = 0;
    }else if(plot.type == TYPE_0x01 && strcmp(HEADER_CON_KO,plot.HEADER) == 0){
        write(1, "ERROR: Unable to connect to Poole!\n", strlen("ERROR: Unable to connect to Poole!\n"));
        close(bowman.fdPoole);
        bowman.fdPoole = -1;
        i = -1;
    }else{
        write(1, "\nUnknown command received!!!\n", strlen("\nUnknown command received!!!\n"));
        plotString = plotGenerator(TYPE_0x07, HEADER_UNKNOWN, NULL, 0, NULL);
        write(bowman.fdPoole, plotString, 256);
        free(plotString);
        i = -1;
    }

    freePlot(plot);
    return i;
}

int userConnect()
{
    if(discoveryConnection() == -1){
        return -1;
    }
    if(pooleConnection() == -1){
        return -1;
    }
    return 0;
}

void informDiscovery_PooleDisconnection(){

    int fdDsicovery = clientConnection(bowman.discovery_port, bowman.discovery_ip, "DISCOVERY");

    if(fdDsicovery<0){
        FreeTheMalloc();
        exit(-1);
    }

    void **data;                       //[PooleName & bowmanName]
    data = malloc(sizeof(void*) * 2);
    data[0] = (void*) bowman.server_name;
    data[1] = (void*) bowman.user_name;

    int *dataSize;
    dataSize = malloc(sizeof(int) * 2);
    dataSize[0] = (int) strlen(bowman.server_name);
    dataSize[1] = (int) strlen(bowman.user_name);

    
    void *plot = plotGenerator(TYPE_0x06,HEADER_DELETE_BOWMAN,data,2,dataSize);

    write(fdDsicovery,plot,256);

    Handle_Discovery_Bowman(fdDsicovery);
    free(plot);
    free(dataSize);
    free(data);
    close(fdDsicovery);
}

void userDisconnect()
{
    char *plotString;
    void **data;
    data = malloc(sizeof(void*) * 1);
    data[0] = (void *) bowman.user_name;

    int *dataSize;
    dataSize = malloc(sizeof(int));
    dataSize[0] = (int) strlen(bowman.user_name);

    plotString = plotGenerator(TYPE_0x06, "EXIT", data,1, dataSize);

    write(bowman.fdPoole, plotString, 256);

    free(plotString);
    free(dataSize);
    free(data);
}

int getNumbytes(Plot plot){  //trames.h ?????? debug

    char *headerCopy;
    char *numBytesString;
    headerCopy = malloc(strlen(plot.HEADER) + 1);
    strcpy(headerCopy, plot.HEADER);

    strtok(headerCopy, "E");
    strtok(NULL, "E");
    numBytesString = strtok(NULL, "E");

    int numBytes = atoi(numBytesString);

    free(headerCopy);

    return numBytes;
}

int getNumElements(char *fullPlotString, char *delimiter){

    int i = 0;
    int numElements = 0;
    while(fullPlotString[i] != '\0'){
        if(fullPlotString[i] == delimiter[0]){
            numElements++;
        }
        
        i++;
    }
    numElements++;
    return numElements;
}

void printSongsList(int numSongs, char *songsString) {
    char *buffer;
    char *songName;

    asprintf(&buffer, "There are %d songs available for download: \n", numSongs);
    write(1, buffer, strlen(buffer));
    free(buffer);

    asprintf(&buffer, "Length of songsString: %ld\n", strlen(songsString));
    write(1, buffer, strlen(buffer));
    free(buffer);

    songName = strtok(songsString, "&");
    int i = 1;
    while (songName != NULL) {
        asprintf(&buffer, "%d. %s (Length: %ld)\n", i, songName, strlen(songName));
        write(1, buffer, strlen(buffer));
        free(buffer);

        songName = strtok(NULL, "&");
        i++;
    }
}

char *getFullPlotData(char *delimiter){

    int numBytes = -1000;
    char *songsString;
    songsString = malloc(1);
    songsString[0] = '\0';
    int idCua = msgget(ftok("Bowman.c", delimiter[0] + getpid()), 0600 | IPC_CREAT);
    if(idCua == -1){
        perror("MSGGET queue");
    }
    QueueMessage msgCua;
    do{
        if(msgrcv (idCua, (void*) (&msgCua), sizeof(Plot) + 1, 1, 0) == -1){
        }


        if(numBytes == -1000){
            numBytes = getNumbytes(msgCua.plot);
        }
      
        songsString = realloc(songsString, strlen(songsString)  + strlen(msgCua.plot.data) + 2);

        strcat(songsString, msgCua.plot.data);
        
        strcat(songsString, delimiter);

        numBytes -= strlen(msgCua.plot.data);
        
        freePlot(msgCua.plot);
    }while(numBytes > 0);

    songsString[strlen(songsString) - 1] = '\0';
    msgctl (idCua, IPC_RMID, NULL);

    return songsString;
}

char **splitPlayLists(char *stringPlayLists) {
    char **playlists = NULL;
    int i = 0;

    char *buffer = strtok(stringPlayLists, "#");
    while (buffer != NULL) {
        playlists = realloc(playlists, sizeof(char *) * (i + 1));

        playlists[i] = malloc(strlen(buffer) + 1); 
        strcpy(playlists[i], buffer);

        buffer = strtok(NULL, "#");
        i++;
    }

    playlists = realloc(playlists, sizeof(char *) * (i + 1));
    playlists[i] = NULL;

    return playlists;
}

void printPlaylists(int numPlayLists, char *playListsString){

    char *buffer;
    char *elementName;
    char **playLists;

    playLists = splitPlayLists(playListsString);   //posible error con strtok (debug)
    
    asprintf(&buffer, "There are %d lists available for download: \n", numPlayLists);
    write(1, buffer, strlen(buffer));
    free(buffer);

    int i = 0;
    int n;
    do{
        elementName = strtok(playLists[i], "&");
        asprintf(&buffer, "%d. %s\n", i + 1, elementName);
        write(1, buffer, strlen(buffer));
        free(buffer);

        n = 0;
        elementName = strtok(NULL, "&");
        while(elementName != NULL){
            
            asprintf(&buffer, "\t%c. %s\n", n + 97, elementName);
            write(1, buffer, strlen(buffer));
            free(buffer);

            elementName = strtok(NULL, "&");
            n++;
        }
        
        i++;
    }while(numPlayLists > i);

    i = 0;
    while(numPlayLists >= i){
        free(playLists[i]);
        i++;
    }

    free(playLists);
}

void printProgressBar(int i){
    char *buffer;

    asprintf(&buffer, "%d%% |", downloads.downloadPercentage[i]);
    write(1, buffer, strlen(buffer));
    free(buffer);

    int n = 0;
    while(downloads.downloadPercentage[i] > n){
        write(1, "-", 1);
        n += 5;
    }
    write(1, "%%", 1);
    while(100 > n){
        write(1, " ", 1);
        n += 5;
    }
    write(1, "|", 1);
}

void checkDownloads(){

    semaphore printSemaphore;
    SEM_constructor_with_name(&printSemaphore, ftok("Bowman.c", 'B'));
    int i = 0;
    char *buffer;
    while(downloads.numDownloads > i){
        asprintf(&buffer, "%s\n\t", downloads.fileName[i]);
        write(1, buffer, strlen(buffer));
        free(buffer);

        printProgressBar(i);
        write(1, "\n", 1);
        i++;
    }

    if(downloads.numDownloads == 0){
        write(1, "\nThere are not downloads running\n", strlen("\nThere are not downloads running\n"));
    }
    SEM_signal(&printSemaphore);
}

void deleteDownload(int i){

    while(downloads.numDownloads > (i + 1) ){
        downloads.downloadPercentage[i] = downloads.downloadPercentage[i + 1];
        downloads.fileName[i] = realloc(downloads.fileName[i], strlen(downloads.fileName[i + 1])  + 1 );
        strcpy(downloads.fileName[i], downloads.fileName[i + 1]);

        i++;
    }
    downloads.numDownloads--;
    free(downloads.fileName[downloads.numDownloads]);
    downloads.downloadPercentage = realloc(downloads.downloadPercentage, downloads.numDownloads);
    downloads.fileName = realloc(downloads.fileName, downloads.numDownloads);
}

void clearDownloads(){
    semaphore printSemaphore;
    SEM_constructor_with_name(&printSemaphore, ftok("Bowman.c", 'B'));
    int i = 0;
    while(downloads.numDownloads > i){

        if(downloads.downloadPercentage[i] == 100){
            deleteDownload(i);
        }

        i++;
    }

    checkDownloads();
    SEM_signal(&printSemaphore);
}

void downloadSong(char *fileName){
    char *plotString;
    void **data;
    data = malloc(sizeof(void*));
    data[0] = (void *) fileName;

    int *dataSize;
    dataSize = malloc(sizeof(int));
    dataSize[0] = strlen(fileName);

    plotString = plotGenerator(TYPE_0x03, "DOWNLOAD_SONG", data, 1, dataSize);
    write(bowman.fdPoole, plotString, 256);
    free(plotString);
    free(dataSize);
    free(data);
}
void downloadPlaylist(char *fileName){
    char *plotString;
    void **data;
    data = malloc(sizeof(void*));
    data[0] = (void *) fileName;

    int *dataSize;
    dataSize = malloc(sizeof(int));
    dataSize[0] = strlen(fileName);

    plotString = plotGenerator(TYPE_0x03, HEADER_DOWNLOAD_LIST, data, 1, dataSize);
    write(bowman.fdPoole, plotString, 256);

    free(plotString);
    free(dataSize);
    free(data);
}

int isSong(char *filename){
    int fileNameLenght;
    fileNameLenght = strlen(filename);
    if((filename[fileNameLenght - 3] == 'm') && (filename[fileNameLenght - 2] == 'p') && (filename[fileNameLenght - 1] == '3')){
        return 0;
    }else{
        return 1;
    }
}

void* songResponseFunction(void *argv){
    semaphore printSemaphore;
    SEM_constructor_with_name(&printSemaphore, ftok("Bowman.c", 'B'));
    pthread_t *thread_activity = (pthread_t*) argv;

    char *fullPlotData;
    char *delimiter;
    delimiter = malloc(2);
    delimiter[0] = '&';
    delimiter[1] = '\0';
    fullPlotData = getFullPlotData(delimiter);

    int numSongs = getNumElements(fullPlotData, delimiter);
    printSongsList(numSongs, fullPlotData);

    free(delimiter);
    free(fullPlotData);

    *thread_activity = 0;

    SEM_signal(&printSemaphore);
    
    return NULL;
}

void* playlistResponseFunction(void *argv){

    semaphore printSemaphore;
    SEM_constructor_with_name(&printSemaphore, ftok("Bowman.c", 'B'));
    pthread_t *thread_activity = (pthread_t*) argv;

    char *fullPlotData;
    char *delimiter;
    delimiter = malloc(2);
    delimiter[0] = '#';
    delimiter[1] = '\0';
    fullPlotData = getFullPlotData(delimiter);
    int numPlayLists = getNumElements(fullPlotData, delimiter);
    
    printPlaylists(numPlayLists, fullPlotData);

    free(delimiter);
    free(fullPlotData);

    *thread_activity = 0;
    SEM_signal(&printSemaphore);
    return NULL;
}

void *fileDataResponseFunction(void *argv){

    semaphore downloadsSemaphore;
    SEM_constructor_with_name(&downloadsSemaphore, ftok("Bowman.c", 'J'));
    SEM_wait(&downloadsSemaphore);

    int *idFilePtr = (int*) argv;
    downloads.numDownloads++;
    int downloadID = downloads.numDownloads - 1;
    SEM_signal(&downloadsSemaphore);

    int idCua = msgget(ftok("Bowman.c",(*idFilePtr + getpid()*7)), 0600 | IPC_CREAT);
    Plot plot = getPlotFromCua(idCua); 
    
    char *token = NULL;
    char *data = strdup(plot.data);
    freePlot(plot);
    token = strtok(data, "&");
    char *fileName = strdup(token);
    token = strtok(NULL, "&");
    int bytesToRead = atoi(token);
    token = strtok(NULL, "&");
    char *md5sum = strdup(token);

    char *fileFinalName;
    asprintf(&fileFinalName,"Songs%s",bowman.user_path);

    checkDirectory(fileFinalName);
    free(fileFinalName);

    asprintf(&fileFinalName,"Songs%s/%s",bowman.user_path,fileName);
    
    int fdFile = open(fileFinalName,O_WRONLY | O_CREAT | O_TRUNC, 0755);
    
    

    if(fdFile==-1){
        perror("socket file creator");
    }
    createFile(fdFile,idCua,bytesToRead, &(downloads.downloadPercentage[downloadID]));
    char md5sumNew[32];
    get_MD5SUM(md5sumNew,fileFinalName);

    if(strcmp(md5sum,md5sumNew)!=0){
        char *string;
        asprintf(&string,"Error en el fitxer MD5SUM ERROR");
        write(1,string,strlen(string));
        void *plotString = plotGenerator(TYPE_0x05, HEADER_CHECK_KO, NULL, 0, NULL);
        write(bowman.fdPoole,plotString,256);
    }
    void *plotString = plotGenerator(TYPE_0x05, HEADER_CHECK_KO, NULL, 0, NULL);
    write(bowman.fdPoole,plotString,256);
    free(plotString);
    free(data);
    free(md5sum);
    free(fileFinalName);
    free(fileName);

    cuaDesctructor(idCua, &bustia);
    write(1,"Cua eliminada\n",strlen("Cua eliminada\n"));
    return NULL;

}
//Thread que llegeix de la cua de missatges
void *bowmanQueueMessasgeReader(){

    QueueMessage msgCua;
    pthread_t *thread_id;
    thread_id =(pthread_t*) malloc(sizeof(pthread_t) * 5); // Array on guardem pthread_id per a comandes

    pthread_t *thread_file_id;
    thread_file_id = malloc(sizeof(pthread_t));

    pthread_t *thread_activity;
    thread_activity =(pthread_t*) malloc(sizeof(pthread_t) * 5);

    int *idCues;
    idCues = malloc(sizeof(int) * 5); 

    int i = 0;
    while(i < 5){
        thread_id[i] = 0;
        thread_activity[i] = 0;
        i++;
    }

    int idCommandQueue = msgget(ftok("Bowman.c", getpid()), 0600 | IPC_CREAT);
    if(idCommandQueue == -1){
        perror("MSGGET queue");
    }

    semaphore downloadsSemaphore;
    SEM_constructor_with_name(&downloadsSemaphore, ftok("Bowman.c", 'J'));
    printf("\nDownload Semafor ID: %d\n", downloadsSemaphore.shmid);//debug
    SEM_init(&downloadsSemaphore, 1);

    bustia.cues = NULL;
    
    while(bowman.fdPoole != -1){
        
        if(msgrcv (idCommandQueue, (void*) (&msgCua), sizeof(Plot), 1, 0) == -1){
        }

        if(strcmp(msgCua.plot.HEADER, HEADER_CON_OK) == 0){
            

            informDiscovery_PooleDisconnection();
            freePlot(msgCua.plot);
            break;
        }else if (strcmp(msgCua.plot.HEADER, HEADER_CON_KO) == 0)
        {
            freePlot(msgCua.plot);
        }else if (strncmp(msgCua.plot.HEADER, HEADER_SONGS_RESPONSE, 14) == 0)
        {
            if(thread_activity[0] == 0){
                
                thread_activity[0] = 1;
                idCues[0] = msgget(ftok("Bowman.c", ('&' + getpid())), 0600 | IPC_CREAT);   //tancar la cua desde el thread
                pthread_create( &(thread_id[0]), NULL, songResponseFunction, (void*)&(thread_activity[0]));  //igualar el thread_id a 0 desde el thread
                pthread_detach(thread_id[0]);
            }
            msgsnd (idCues[0], (void*) (&msgCua), sizeof(Plot), 0);
            
        }else if (strncmp(msgCua.plot.HEADER, HEADER_PLAYLISTS_RESPONSE, 18) == 0)
        {
            if(thread_activity[1] == 0){
                thread_activity[1] = 1;
                pthread_create( &(thread_id[1]), NULL, playlistResponseFunction, (void*)&(thread_activity[1]));  //igualar el thread_id a 0 desde el thread
                idCues[1] = msgget(ftok("Bowman.c", ('#' + getpid())), 0600 | IPC_CREAT);   //tancar la cua desde el thread
                pthread_detach(thread_id[1]);
            }
            msgsnd (idCues[1], (void*) (&msgCua), sizeof(Plot), 0);

        }else if (strcmp(msgCua.plot.HEADER, HEADER_NEW_FILE) == 0)
        {
            int idCua;
            
            int idFile = getIdFromPlotNEW(msgCua.plot);
            key_t key = ftok("Bowman.c",(idFile + getpid()*7));
            idCua = cuaCreator(key,idFile,&bustia);
            if(idCua!=-1){
                
                downloads.fileName = realloc(downloads.fileName, sizeof(char*) * (downloads.numDownloads + 1));
                downloads.downloadPercentage = realloc(downloads.downloadPercentage, sizeof(int) * (downloads.numDownloads + 1));
                downloads.fileName[downloads.numDownloads] = getSongNameFromPlot(msgCua.plot);
                if(bustia.numCues>0){
                    thread_file_id = realloc(thread_file_id,(sizeof(pthread_t) * bustia.numCues));

                }
                if(bustia.numCues>0){
                    pthread_create( &(thread_file_id[bustia.numCues - 1]), NULL, fileDataResponseFunction, (void*)(&idFile));
                    pthread_detach(thread_file_id[bustia.numCues - 1]);
                    write(1,"Download started!\n",strlen("Download started!\n"));
                    semaphore printSemaphore;
                    SEM_constructor_with_name(&printSemaphore, ftok("Bowman.c", 'B'));
                    SEM_signal(&printSemaphore);
                }
            }
            msgsnd (idCua, (void*) (&msgCua), sizeof(Plot), 0);

            
        }else if (strcmp(msgCua.plot.HEADER, HEADER_FILE_DATA) == 0)
        {
            
            int idFile = getIdFromPlotDATA(msgCua.plot);
            int idCua = getCuaFromID(idFile, bustia);
            
            msgsnd (idCua, (void*) (&msgCua), sizeof(Plot), 0);
        }else if (strcmp(msgCua.plot.HEADER, HEADER_UNKNOWN) == 0)
        {
            write(1,"This file does not exist in our Library!\n",strlen("This file does not exist in our Library!\n"));
            
            semaphore printSemaphore;
            SEM_constructor_with_name(&printSemaphore, ftok("Bowman.c", 'B'));
            SEM_signal(&printSemaphore);
            
        }else{
            freePlot(msgCua.plot);
        }
        
    }

    msgctl (idCommandQueue, IPC_RMID, NULL);
    free(thread_id);
    free(thread_activity);
    free(thread_file_id);
    free(idCues);

    return NULL;
}

//Thread que llegeix i guarda les dades desde el socket a la cua de missatges
void *bowmanSocketMessageReader(){

    Plot plot;

    QueueMessage msgCua;
    int idCommandQueue = msgget(ftok("Bowman.c", getpid()), 0600 | IPC_CREAT);
    if(idCommandQueue == -1){
    }
    
    while(bowman.fdPoole != -1){
        plot = plotReader(bowman.fdPoole);
        if(plot.HEADER == NULL){
            
            if(bowman.poole_ip == NULL){
                freePlot(plot);
                break;
            }else{
                freePlot(plot);
                close(bowman.fdPoole);
                bowman.fdPoole = -1;
                userConnect();
            }
            
        }else{
            msgCua.plot = plot;
            msgCua.msgID = 1;
            
            msgsnd (idCommandQueue, (void*) (&msgCua), sizeof(Plot), 0);
        }
    }
    
    close(bowman.fdPoole);
    bowman.fdPoole = -1;
    return NULL;
}

void sendListSongs(){
    char *plotString;   

    plotString = plotGenerator(TYPE_0x02, "LIST_SONGS", NULL, 0, NULL);   //--------

    write(bowman.fdPoole, plotString, 256);
    free(plotString);
}

void sendListPlaylists(){   
    char *plotString;

    plotString = plotGenerator(TYPE_0x02, "LIST_PLAYLISTS", NULL, 0, NULL);   //--------

    write(bowman.fdPoole, plotString, 256);
    free(plotString);
}

int AnswerMultiplexer(){
    semaphore printSemaphore;
    SEM_constructor_with_name(&printSemaphore, ftok("Bowman.c", 'B'));

    char *input = NULL;
    input = read_until(0,'\n');
    if(input==NULL){
        SEM_signal(&printSemaphore);
        return 0;
    }
    CheckStringSpaces(input);

    int answer_id;
    answer_id = ReadChatBuffer(input);
    
    
    switch(answer_id){
        case ID_NO_MATCH:
            write(1, "\nUnknown command\n", strlen("\nUnknown command\n"));
            SEM_signal(&printSemaphore);
            break;
        case ID_CONNECT:
            if(bowman.fdPoole < 0){
                if(userConnect() == -1){
                    free(input);
                    return -1;
                }
            }else{
                write(1, "You are already connected\n", strlen("You are already connected\n"));
                SEM_signal(&printSemaphore);
            }
            
            break;
        case ID_LOGOUT:
            
            if(bowman.fdPoole > 0){
                free(bowman.poole_ip);
                bowman.poole_ip = NULL; 
                userDisconnect();
                free(input);
                return -1;
            }else{
                write(1, "Connect first\n", strlen("Connect first\n"));
                SEM_signal(&printSemaphore);
            }
            break;
        case ID_CHECK_DOWNLOADS:

            if(bowman.fdPoole > 0){
                checkDownloads();
            }else{
                write(1, "Cannot check downloads, you are not connected to HAL 9000\n", strlen("Cannot check downloads, you are not connected to HAL 9000\n"));
                SEM_signal(&printSemaphore);
            }
            break;
        case ID_CLEAR_DOWNLOADS:

            if(bowman.fdPoole > 0){
                clearDownloads();
            }else{
                write(1, "Cannot clear downloads, you are not connected to HAL 9000\n", strlen("Cannot clear downloads, you are not connected to HAL 9000\n"));
                SEM_signal(&printSemaphore);
            }
            
            break;
        case ID_DOWNLOAD:
            if(bowman.fdPoole > 0){
                char *fileName;
                strtok(input, " ");
                fileName = strtok(NULL, " ");
                write(1,fileName,strlen(fileName));
                if(isSong(fileName) == 0){
                    strtok(fileName, ".");
                    strtok(fileName, ".");
                    downloadSong(fileName);
                }else{
                    downloadPlaylist(fileName);
                    SEM_signal(&printSemaphore);
                }
                
            }else{
                write(1, "Cannot download, you are not connected to HAL 9000\n", strlen("Cannot download, you are not connected to HAL 9000\n"));
                SEM_signal(&printSemaphore);
            }
            break;
        case ID_LIST_PLAYLISTS:
            if(bowman.fdPoole > 0){
                sendListPlaylists();
            }else{
                write(1, "Cannot List playlists, you are not connected to HAL 9000\n", strlen("Cannot List playlists, you are not connected to HAL 9000\n"));
                SEM_signal(&printSemaphore);
            }
            break;
        case ID_LIST_SONGS:
            if(bowman.fdPoole > 0){
                sendListSongs();
            }else{
                write(1, "Cannot List songs, you are not connected to HAL 9000\n", strlen("Cannot Lists songs, you are not connected to HAL 9000\n"));
                SEM_signal(&printSemaphore);
            }
            break;
    }
    free(input);

    return 0;
}

//-------------------------------START FREE THE MALLOC------------------------------------------------------

void freeDownloads(){
    
    while(downloads.numDownloads > 0){
        free(downloads.fileName[downloads.numDownloads - 1]);
        downloads.numDownloads--;
    }
    free(downloads.downloadPercentage);
    free(downloads.fileName);
}

void FreeTheMalloc(){
    if(bowman.fdPoole > 0){
        free(bowman.poole_ip);
        bowman.poole_ip = NULL; 
        userDisconnect();
        informDiscovery_PooleDisconnection();
        pthread_join(bowman.readerThreadsID[0], NULL);
        pthread_join(bowman.readerThreadsID[1], NULL);
    }

    

    freeDownloads();
    free(bowman.readerThreadsID);
    free(bowman.user_name);
    free(bowman.user_path);
    free(bowman.discovery_ip);
    if(bowman.poole_ip != NULL){
        free(bowman.poole_ip);
    }

    semaphore printSemaphore;
    SEM_constructor_with_name(&printSemaphore, ftok("Bowman.c", 'B'));
    SEM_destructor(&printSemaphore);

    semaphore downloadsSemaphore;
    SEM_constructor_with_name(&downloadsSemaphore, ftok("Bowman.c", 'J'));
    SEM_destructor(&downloadsSemaphore);

    free(bowman.server_name);
}
//-------------------------------END FREE THE MALLOC------------------------------------------------------

//-------------------------------START SIGNAL------------------------------------------------------
void CtrlCHandler(){
    FreeTheMalloc();
    exit(0);
}

void SignalConfig(){
    signal(SIGINT,CtrlCHandler);
}

//-------------------------------END SIGNAL------------------------------------------------------

//-------------------------------MAIN------------------------------------------------------
int main(int argc,char *argv[]){


    SignalConfig();

    int fd;
    if(argc!=2){
        write(1,"\nNo has executat correctement el Bowman\n",strlen("\nNo has executat correctement el Bowman\n"));
        exit(0);
    }
    
    openFile(&fd,argv[1]);
    readConfig(fd);

    closeFile(fd);

    //Connexio ja acceptada
    //Menu

    semaphore printSemaphore;
    SEM_constructor_with_name(&printSemaphore, ftok("Bowman.c", 'B'));
    SEM_init(&printSemaphore, 1);
    printf("\nPrint Semafor ID: %d\n", printSemaphore.shmid);//debug

    write(1, bowman.user_name, strlen(bowman.user_name));
    write(1," user initialized\n",strlen(" user initialized\n"));
    do{
        SEM_wait(&printSemaphore);
        write(1,"\033[1;33m",strlen("\033[1;33m"));
        write(1,"\n$ ",strlen("\n$ "));
        write(1,"\033[0m",strlen("\033[0m"));
        
    }while(AnswerMultiplexer() == 0);

    pthread_join(bowman.readerThreadsID[0], NULL);
    pthread_join(bowman.readerThreadsID[1], NULL);

    FreeTheMalloc();

    return 0;
}
